package com.psl.emp.action;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.psl.emp.constant.ErrorCodes;
import com.psl.emp.constant.ApiConstants;





public class LoginAction extends DispatchAction {

	private static final long serialVersionUID = 5539422250920232971L;
	private static final Logger logger = Logger
			.getLogger(LoginAction.class);
	
	HttpSession session = null;
	
	private String errMsg = "";
	private String retVal = "";
	private String info = "";
	Map<String, String> userType = new HashMap<String, String>();
	
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		if (request.getSession(false) == null)
		{ 
			//Session expired 
			errMsg = ErrorCodes.SESSIONEXPIRE;	
			logger.info(errMsg);
			retVal =  ApiConstants.LOGIN;	  
		} else {

			userType.put("Admin", "Admin");
			userType.put("Employee", "Employee");
		//SpringUtil.getSpringUtil().getService("customerAddressService");
		info = (String)request.getParameter("info");
		request.setAttribute("info", info);
		request.setAttribute("userType", userType);
		retVal =  ApiConstants.SUCCESS;	  
		}
		
		return mapping.findForward(retVal);
		
	}
	
	
	
	public ActionForward logOut(ActionMapping mapping,ActionForm form,HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		if (request.getSession(false) == null)
		{ 
			//Session expired 
			errMsg = ErrorCodes.SESSIONEXPIRE;	
			logger.info(errMsg);
			retVal =  ApiConstants.LOGIN;	  
		} else {

		//SpringUtil.getSpringUtil().getService("customerAddressService");
		info =" You have logged out successfully ";
		request.setAttribute("info", info);
		retVal =  ApiConstants.SUCCESS;	  
		}
		
		return mapping.findForward(retVal);
		
	}
	
	
	public ActionForward employeeDetails(ActionMapping mapping,ActionForm form,HttpServletRequest request,
			HttpServletResponse response) throws Exception
	{
		if (request.getSession(false) == null)
		{ 
			//Session expired 
			errMsg = ErrorCodes.SESSIONEXPIRE;	
			logger.info(errMsg);
			retVal =  ApiConstants.LOGIN;	  
		} else {

			
		
		retVal =  ApiConstants.SUCCESS;	  
		}
		
		return mapping.findForward(retVal);
		
	}
	
	
	
	
	
	
	
	
	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	
	
	/*
	HttpSession session = null;
	HttpServletRequest request = (HttpServletRequest) ActionContext
			.getContext().get(ServletActionContext.HTTP_REQUEST);
	private String errMsg = "";
	private String retVal = "";
	private String info = "";
	Map<String, String> userType = new HashMap<String, String>();
	
	public String execute() throws Exception {
		
		if (request.getSession(false) == null)
		{ 
			//Session expired 
			errMsg = ErrorCodes.SESSIONEXPIRE;	
			logger.info(errMsg);
			retVal =  ApiConstants.LOGIN;	  
		} else {

			userType.put("Customer", "Customer");
			userType.put("Employee", "Employee");
		//SpringUtil.getSpringUtil().getService("customerAddressService");
		info = (String)request.getParameter("info");
		request.setAttribute("info", info);
		request.setAttribute("userType", userType);
		retVal =  ApiConstants.SUCCESS;	  
		}
		return retVal;
	}
	
public String logOut() throws Exception {
		
		if (request.getSession(false) == null)
		{ 
			//Session expired 
			errMsg = ErrorCodes.SESSIONEXPIRE;	
			logger.info(errMsg);
			retVal =  ApiConstants.LOGIN;	  
		} else {

		//SpringUtil.getSpringUtil().getService("customerAddressService");
		info =" You have logged out successfully ";
		request.setAttribute("info", info);
		retVal =  ApiConstants.SUCCESS;	  
		}
		return retVal;
	}
public String employeeDetails() throws Exception {
	
	if (request.getSession(false) == null)
	{ 
		//Session expired 
		errMsg = ErrorCodes.SESSIONEXPIRE;	
		logger.info(errMsg);
		retVal =  ApiConstants.LOGIN;	  
	} else {

		
	
	retVal =  ApiConstants.SUCCESS;	  
	}
	return retVal;
}
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub

	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	*/
}