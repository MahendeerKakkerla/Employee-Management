package com.psl.emp.action;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.psl.emp.constant.ApiConstants;
import com.psl.emp.constant.ErrorCodes;
import com.psl.emp.constant.PSLException;
import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;
import com.psl.emp.form.EmployeeForm;
import com.psl.emp.service.ValidateLogingUserService;
import com.psl.emp.utils.SpringUtil;

public class NFCUserAction  extends DispatchAction {

	private static final long serialVersionUID = 5539422250920232971L;
	private static final Logger logger = Logger.getLogger(NFCUserAction.class);
	private static HttpServletRequest request = null;
	private String errMsg = "";
	private String retVal = "";
	private String infomsg = "";
	
	private ValidateLogingUserService validateLogingUserService = (ValidateLogingUserService) SpringUtil.getSpringUtil()
			.getService("validateLogingUserService");
	
	public ActionForward getForm(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws Exception {
		request = request1;
		logger.debug("NFCUserAction: getForm method executing Start ");
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {

			EmployeeForm empForm = (EmployeeForm) form;
			if (null == empForm) {
				empForm = new EmployeeForm();
			}
	}
		
		retVal = "success";
		logger.debug("NFCUserAction: getForm method executing end ");
		return mapping.findForward(retVal);
	}
	
	
	public ActionForward logoutTimeOfNFC(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws PSLException, ClassNotFoundException {
		request = request1;
		errMsg = "";
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {

			EmployeeForm empForm = (EmployeeForm) form;

			
			validateLogingUserService.logOutNFC(empForm);
			infomsg = "Details Updated In DataBase....";
			request.setAttribute("infomsg", infomsg);
			retVal = "success";
		}
		return mapping.findForward(retVal);
	}
}
