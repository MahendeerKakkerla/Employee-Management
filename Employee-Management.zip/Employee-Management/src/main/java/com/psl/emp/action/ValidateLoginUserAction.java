package com.psl.emp.action;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.google.gson.JsonSerializer;
import com.psl.emp.constant.EmailException;
import com.psl.emp.constant.ErrorCodes;
import com.psl.emp.constant.ApiConstants;
import com.psl.emp.constant.PSLException;
import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;
import com.psl.emp.form.EmployeeForm;
import com.psl.emp.service.EmailerService;
import com.psl.emp.service.ValidateLogingUserService;
import com.psl.emp.utils.SpringUtil;


/**
 * @author mahender_kakkerla
 *
 */
public class ValidateLoginUserAction extends DispatchAction {

	private static final long serialVersionUID = 5539422250920232971L;
	private static final Logger logger = Logger.getLogger(ValidateLoginUserAction.class);
	HttpSession session = null;

	String errMsg = "";
	private String retVal = "";
	private String infomsg = "";
	private String customerType_info = "";
	public transient JsonSerializer serializer;

	private static HttpServletRequest request = null;
	private ValidateLogingUserService validateLogingUserService = (ValidateLogingUserService) SpringUtil.getSpringUtil()
			.getService("validateLogingUserService");
	private EmailerService emailerService = (EmailerService) SpringUtil.getSpringUtil()
			.getService("emailerService");
private String fullName = "";

/**
 * Validate login user.
 * @param mapping
 * @param form
 * @param request1
 * @param response
 * @return ActionForward
 * @throws Exception
 */
	public ActionForward validateUser(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws Exception {
		request = request1;
		logger.debug("ValidateLoginUserAction: validateUser method executing start ");
		String loginId = request.getParameter("loginId");
		String password = request.getParameter("password");
		String userType = request.getParameter("userType");

		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {
			
			EmployeeForm empForm = (EmployeeForm) form;
			if(null == empForm){
				empForm = new EmployeeForm();
			}
			
			if(null != password){
				password = cryptWithMD5(password);
			}
			empForm.setEmailId(loginId);
			empForm.setPassword(password);
			empForm.setEmpType(userType);

			empForm = validateLogingUserService.getUserDetails(empForm);
			
			if (null != empForm) {
				
				fullName = empForm.getFirstName() +" "+ empForm.getLastName();
				if (userType.equalsIgnoreCase("Admin")) {
					empForm.setEmployeeId(null);
					empForm.setFirstName("");
					empForm.setLastName("");
					empForm.setEmployeeCode("");
					empForm.setPhone("");
					empForm.setDesignation("");
					empForm.setDepartment("");
					empForm.setCity("");
					empForm.setOffice("");
					empForm.setEmailId("");
					empForm.setManagerEmailId("");
					request.setAttribute("infomsg", null);
					request.setAttribute("errMsg", null);
					retVal = "success";
				} else {
					Set<EmployeeLogoutTimeDetailsDO> detailDos = empForm.getDetailsDO();
					sortList(detailDos);
					Date lastDateUpdated = empForm.getCreationDate();
					Date todayDate = new Date();
					if(null != lastDateUpdated){compareDates(lastDateUpdated,todayDate);}
					
					retVal = "empLogin";
				}
				List<EmployeeForm> empForms = validateLogingUserService.getEmployeeDetails();
				request.setAttribute("empForms", empForms);
				
				request.getSession().setAttribute("fullName", fullName);
				request.getSession().setAttribute("employeeFormSesion", empForm);

			} else {
				errMsg = "Your loginid or password is wrong";
				request.setAttribute("errMsg", errMsg);
				logger.error("Customer login failed , loginId is :: " + loginId);
				retVal = "failure";
			}

		}
		logger.debug("ValidateLoginUserAction: validateUser method executing end ");
		return mapping.findForward(retVal);
	}
	
	/**
	 * Save Employee Details.
	 * @param mapping
	 * @param form
	 * @param request1
	 * @param response
	 * @return ActionForward 
	 * @throws PSLException
	 * 
	 */
	public ActionForward saveEmpDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws PSLException, ClassNotFoundException {
		request = request1;
		errMsg = "";
		infomsg = "";
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {
			
			

			EmployeeForm empForm = (EmployeeForm) form;
			
			if(isValidForm(empForm)){

			empForm.setEmpStatus("A");
			empForm.setCreatedby("Admin");
			empForm.setCreationDate(null);
			empForm.setPassword(cryptWithMD5("password123"));
			empForm.setEmpType("Employee");
			boolean isexisted = validateLogingUserService.checkEmployee(empForm);
			if (!isexisted) {
				empForm.setEmployeeId(null);
				EmployeeForm employeeForm = validateLogingUserService.saveEmployee(empForm);
				empForm = employeeForm;
				infomsg = "Saved Successfully......";
			} else {
				
				errMsg = ErrorCodes.EMPLOYEEEXISTED;
				request.setAttribute("errMsg", errMsg);
			}
			
			}else{
				request.setAttribute("errMsg", errMsg);
			}
			
			List<EmployeeForm> empForms = validateLogingUserService.getEmployeeDetails();
			request.setAttribute("empForms", empForms);

			request.setAttribute("infomsg", infomsg);
			retVal = "success";
		}
		return mapping.getInputForward();
	}
	/**
	 * Save logout time details.
	 * @param mapping
	 * @param form
	 * @param request1
	 * @param response
	 * @return ActionForward
	 * @throws PSLException
	 * @throws ClassNotFoundException
	 */
	public ActionForward logoutTimeOfEmployee(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws PSLException, ClassNotFoundException {
		request = request1;
		errMsg = "";
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {

			EmployeeForm empForm = (EmployeeForm) form;

			empForm.setEmpStatus("A");
			empForm.setCreatedby("Admin");
			empForm.setCreationDate(new Date());
			 
			empForm.setPassword(cryptWithMD5("password123"));
			empForm.setEmpType("Employee");
			empForm.setLogoutTime(new Date());
			Set<EmployeeLogoutTimeDetailsDO> detailDos = new HashSet<EmployeeLogoutTimeDetailsDO>();
			EmployeeLogoutTimeDetailsDO employeeLogoutTimeDetailsDO = new EmployeeLogoutTimeDetailsDO();
			
			SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");

			String dateAsString = dateFormatter.format(new Date());
			String timeAsString = timeFormatter.format(new Date());
			employeeLogoutTimeDetailsDO.setOutDate(dateAsString);
			employeeLogoutTimeDetailsDO.setOutTime(timeAsString);
			employeeLogoutTimeDetailsDO.setDayName(LocalDate.now().getDayOfWeek().name());
			detailDos.add(employeeLogoutTimeDetailsDO);
			empForm.setDetailsDO(detailDos);

			empForm = validateLogingUserService.saveEmployee(empForm);
			empForm = validateLogingUserService.getEmployee(empForm);
			Set<EmployeeLogoutTimeDetailsDO> detailsDo = empForm.getDetailsDO();
			
			sortList(detailsDo);
			if (errMsg == "") {
				infomsg = "Record Exist Time Saved Successfully......";
			}

			sendMailToManager(empForm);
			request.setAttribute("infomsg", infomsg);
			request.setAttribute("empType", "Employee");
			 request.setAttribute("isDisable", "true");
			retVal = "empLogin";
		}
		return mapping.findForward(retVal);
	}
	/**
	 * Clear Action Form 
	 * @param mapping
	 * @param form
	 * @param request1
	 * @param response
	 * @return ActionForward
	 * @throws PSLException
	 * 
	 */
	public ActionForward clearForm(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws PSLException, ClassNotFoundException {
		request = request1;
		errMsg = "";
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {

			EmployeeForm empForm = (EmployeeForm) form;
			empForm.setEmployeeId(null);
			empForm.setFirstName("");
			empForm.setLastName("");
			empForm.setEmployeeCode("");
			empForm.setPhone("");
			empForm.setDesignation("");
			empForm.setDepartment("");
			empForm.setCity("");
			empForm.setOffice("");
			empForm.setEmailId("");
			empForm.setManagerEmailId("");
			empForm.setAddress1("");
			empForm.setAddress2("");
			empForm.setPincode("");
			empForm.setState("");
			request.setAttribute("infomsg", null);
			request.setAttribute("errMsg", null);
			
			List<EmployeeForm> empForms = validateLogingUserService.getEmployeeDetails();
			request.setAttribute("empForms", empForms);
						
		    retVal = "success";
		}
		return mapping.findForward(retVal);
	}
	/**
	 * Clear Action Form and Get List
	 * @param mapping
	 * @param form
	 * @param request1
	 * @param response
	 * @return ActionForward
	 * @throws PSLException
	 * 
	 */
	public ActionForward employeeList(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws PSLException, ClassNotFoundException {
		request = request1;
		errMsg = "";
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {

			EmployeeForm empForm = (EmployeeForm) form;
			empForm.setEmployeeId(null);
			empForm.setFirstName("");
			empForm.setLastName("");
			empForm.setEmployeeCode("");
			empForm.setPhone("");
			empForm.setDesignation("");
			empForm.setDepartment("");
			empForm.setCity("");
			empForm.setOffice("");
			empForm.setEmailId("");
			empForm.setManagerEmailId("");
			empForm.setAddress1("");
			empForm.setAddress2("");
			empForm.setPincode("");
			empForm.setState("");
			request.setAttribute("infomsg", null);
			request.setAttribute("errMsg", null);
			
			retVal = "success";
		
		List<EmployeeForm> empForms = validateLogingUserService.getEmployeeDetails();
		request.setAttribute("empForms", empForms);
		request.setAttribute("page", "2");
		request.getSession().setAttribute("fullName", fullName);
		}
		return mapping.findForward(retVal);
	}
	/**
	 * Get Employee For Admin.
	 * @param mapping
	 * @param form
	 * @param request1
	 * @param response
	 * @return ActionForward
	 * @throws PSLException
	 * 
	 */
	public ActionForward getEmployeeForAdmin(ActionMapping mapping, ActionForm form, HttpServletRequest request1,
			HttpServletResponse response) throws PSLException, ClassNotFoundException {
		request = request1;
		errMsg = "";
		if (request.getSession(false) == null) {
			// Session expired
			errMsg = ErrorCodes.SESSIONEXPIRE;
			logger.info(errMsg);
			retVal = ApiConstants.LOGIN;
		} else {

			EmployeeForm empForm = (EmployeeForm) form;
			empForm = validateLogingUserService.getEmployeeForAdmin(empForm);
			
			Set<EmployeeLogoutTimeDetailsDO> detailDos = empForm.getDetailsDO();
			sortList(detailDos);
			request.setAttribute("empType", "Admin");
			retVal = "empLogin";
		   
		}
		return mapping.findForward(retVal);
	}
	
	
	
	 private static MessageDigest md;
	 /**
		 * Get Encrypted password 
		 * @param pass
		 * @return
		 */
	   public static String cryptWithMD5(String pass){
	    try {
	        md = MessageDigest.getInstance("MD5");
	        byte[] passBytes = pass.getBytes();
	        md.reset();
	        byte[] digested = md.digest(passBytes);
	        StringBuffer sb = new StringBuffer();
	        for(int i=0;i<digested.length;i++){
	            sb.append(Integer.toHexString(0xff & digested[i]));
	        }
	        return sb.toString();
	    } catch (NoSuchAlgorithmException ex) {
	        // Logger.getLogger(ValidateLoginUserAction.class.getName()).log(Level.SEVERE, null, ex);
	    	logger.info(ex);
	    }
	        return null;


	   }
	
	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	/**
	 * Validate Form from server side validation.
	 * @param empForm
	 * @return
	 */
	public boolean isValidForm(EmployeeForm empForm){
		
		Boolean isValideForm = true;
		if(null == empForm.getFirstName() || empForm.getFirstName().equalsIgnoreCase("") || !isAlpha(empForm.getFirstName())){
			errMsg = errMsg + "Invalide FirstName";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(null == empForm.getLastName() || empForm.getLastName().equalsIgnoreCase("") || !isAlpha(empForm.getLastName())){
			
			errMsg = errMsg + "Invalide LastName";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(null == empForm.getEmployeeCode() || empForm.getEmployeeCode().equalsIgnoreCase("") || !empForm.getEmployeeCode().matches("[A-Za-z0-9]+")){
			
			errMsg = errMsg + "Invalide EmployeeCode";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(null == empForm.getPhone() || empForm.getPhone().equalsIgnoreCase("") || !empForm.getPhone().matches("[0-9]+") || empForm.getPhone().length() !=10){
			
			errMsg = errMsg + "Invalide Moblie Number";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(null == empForm.getEmailId() || empForm.getEmailId().equalsIgnoreCase("") || !isValidEmailAddress(empForm.getEmailId())){
			
			errMsg = errMsg + "Invalide Email";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(null == empForm.getManagerEmailId() || empForm.getManagerEmailId().equalsIgnoreCase("") || !isValidEmailAddress(empForm.getManagerEmailId())){
			
			errMsg = errMsg + "Invalide ManagerEmail";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(!isAlpha(empForm.getDesignation())){
			
			errMsg = errMsg + "Invalide Designation";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(!isAlpha(empForm.getDepartment())){
			
			errMsg = errMsg + "Invalide Department";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(!isAlpha(empForm.getCity())){
			
			errMsg = errMsg + "Invalide City Name";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(!isAlpha(empForm.getState())){
		
			errMsg = errMsg + "Invalide State Name";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(!empForm.getPincode().equalsIgnoreCase("") && (!empForm.getPincode().matches("[0-9]+") || empForm.getPincode().length() !=6)){
			
			errMsg = errMsg + "Invalide Pincode";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		if(null != empForm.getOffice() && empForm.getOffice().equalsIgnoreCase("") && (!isAlpha(empForm.getOffice()))){
			
			errMsg = errMsg + "Invalide Office Name";
			errMsg = errMsg + "<br/>";
			isValideForm = false;
		}
		
		return isValideForm;
	}
	/**
	 * Validate Alpha
	 * @param name
	 * @return
	 */
	public boolean isAlpha(String name)
	{
	    if(null != name && !name.equalsIgnoreCase("")){
	    	
	    	if(name.matches("^[a-zA-Z\\s]*$")){
	    		return true;
	    	}else{
	    		return false;
	    	}
	    
	    }
	    return true;
	}

	/**
	 * This method is used to validate email.
	 * @param email
	 * @return boolean
	 */
	public static boolean isValidEmailAddress(String email) {
		   boolean result = true;
		   try {
		      InternetAddress emailAddr = new InternetAddress(email);
		      emailAddr.validate();
		   } catch (AddressException ex) {
		      result = false;
		   }
		   return result;
		}
	
	/**
	 *  This method is used to compare dates.
	 * @param dateOne
	 * @param dateTwo
	 */
	private static void compareDates(Date dateOne, Date dateTwo) {
		
		
		
		try {
			String strDate1 = formatDate(dateOne,"dd-MMM-yyyy");
			String strDate2= formatDate(dateTwo,"dd-MMM-yyyy");
			  
			SimpleDateFormat sdf = new SimpleDateFormat( "dd-MMM-yyyy" );
			java.util.Date d1 = sdf.parse( strDate1 );
			java.util.Date d2 = sdf.parse( strDate2 );
			  
			System.out.println( "1. " + sdf.format( d1 ).toUpperCase() );
			System.out.println( "2. " + sdf.format( d2 ).toUpperCase() );
			if((d1.compareTo(d2)) ==0){
				 request.setAttribute("isDisable", "true");
			   }
			  if(d1.equals(d2)){
				  request.setAttribute("isDisable", "true");
			  }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/**
	 * This method is used to parse date to string
	 * @param date
	 * @param format
	 * @return String
	 */
	 public static String formatDate(Date date, String format) {
		   SimpleDateFormat form = new SimpleDateFormat(format);
		   return form.format(date);
		  }
	 /**
	 * @param empForm
	 * @throws PSLException
	 * @throws ClassNotFoundException
	 */
	public void sendMailToManager(EmployeeForm empForm ) throws PSLException, ClassNotFoundException {
			
		/*	String to = "mahender_kakkerla@persistent.co.in";
			String sub = "Logout Time Of  "+empForm.getFirstName()+" "+empForm.getLastName();

			String emailMsg = "Dear "
					+ "Manager "
					+ ","
					+ "\n"
					+ "\n"
					+ "  Employee "+empForm.getEmployeeCode()+" logoutted time is: "+empForm.getLogoutTime()
					+ "\n"
					+"\n"+"\n"+"Please do not respond to this email , this is an unmonitored address and replies to this emails cannot be read or responded " +
					"\n"+"\n"+"\n"+"Yours In-Service";
			
			
				emailerService.sendMail(to, sub, emailMsg);*/
		String host = "smtp.gmail.com";
		String port = "587";
		String mailFrom = "kakkerla.mahender@gmail.com";
		String password = "9010158627";

		// outgoing message information
		String mailTo = "mahender_kakkerla@persistent.co.in";
		String subject = "Employees Working Hours";

		String employeeName = "<font face='Times New Roman'  size = '3'>" + empForm.getFirstName() + " "
				+ empForm.getLastName() + "</font>";
		String employeeCode = "<font face='Times New Roman'  size = '3'>" + empForm.getEmployeeCode() + "</font>";
		String logoutTime = "<font face='Times New Roman'  size = '3'>" + dateToStringFormatter(empForm.getLogoutTime())
				+ "</font>";

		// message contains HTML markups
		String message = "<font face='Times New Roman'  size = '3'>Hello Shilbodhi Shambharkar,</font><br>";
		message += "<br><br>";
		message += "<font face='Times New Roman' size = '3'>This is Informing you that your employee logout time details as below. This will help managers to assess the need of their working hours.</font><br>";
		message += "<br><br>";
		message += "<font face='Times New Roman' size = '3'> <table border='1'><tr><td>Employee Name</td><td>Employee Code</td><td>Out Time</td></tr><tr><td>"
				+ employeeName + "</td><td>" + employeeCode + "</td><td>" + logoutTime
				+ "</td></tr></table> </font><br>";
		message += "<br>";
		message += "<font face='Times New Roman' size = '3'>This is for your information.</font><br>";
		message += "<font face='Times New Roman' size = '3'>Management System.</font><br>";

		try {
			emailerService.sendHtmlEmail(host, port, mailFrom, password, mailTo, subject, message);
		} catch (AddressException e) {

			e.printStackTrace();
		} catch (MessagingException e) {

			e.printStackTrace();
		}
			
			
		}
	/** Convert Date To String Formatter
	 * @param sourceDate
	 * @return String
	 */
	private static String DDMMYYYYHHMMSS_SLASH_FORMAT = "dd-MMM-yyyy hh:mm:ss a";
	public static String dateToStringFormatter(Date sourceDate) {
		String convertedDateStr = null;
		SimpleDateFormat sdfOutput = new SimpleDateFormat(DDMMYYYYHHMMSS_SLASH_FORMAT);
		try {
			convertedDateStr = sdfOutput.format(sourceDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return convertedDateStr;
	}
	/**
	 * This method is used to sort employee logout details.
	 * @param detailDos
	 */
	private void sortList(Set<EmployeeLogoutTimeDetailsDO> detailDos){
		 
		 List<EmployeeLogoutTimeDetailsDO> sortedList = new ArrayList<EmployeeLogoutTimeDetailsDO>(detailDos);
			Collections.sort(sortedList, new Comparator<EmployeeLogoutTimeDetailsDO>() {
			    public int compare(EmployeeLogoutTimeDetailsDO o1, EmployeeLogoutTimeDetailsDO o2) {
			        return o1.getDetailId().compareTo(
			                o2.getDetailId());
			    }
			});
			request.setAttribute("detailDos", sortedList);
	 }
	
}
