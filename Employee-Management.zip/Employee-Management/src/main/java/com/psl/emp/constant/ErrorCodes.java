package com.psl.emp.constant;

/**
 * @author mahender_kakkerla
 *
 */
public final class ErrorCodes{

	
	
	public static final String INVALIDPWD="Login Failure";
	
	public static final String SESSIONEXPIRE="Session Expired";
	public static final String EMPLOYEEEXISTED="Employee Existed In System.";

}
