package com.psl.emp.constant;

/**
 * @author mahender_kakkerla
 *
 */
public class PSLException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String error;

	private Throwable t;

	public PSLException() {
	}

	public PSLException(String err) {
		this.error = err;
	}

	public PSLException(String err, Throwable t) {
		this.error = err;
		this.t = t;
	}

	public String getError() {
		return error;
	}


}