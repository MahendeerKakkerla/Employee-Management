package com.psl.emp.dao;

import java.util.List;

import com.psl.emp.constant.PSLException;
import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.form.EmployeeForm;

/**
 * @author mahender_kakkerla
 *
 */
public interface ValidateLogingUserDAO {

	/**
	 * Gets the login Details.
	 * @param loginId and password
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeDO getUserDetails(EmployeeDO domain) throws PSLException;
	
	/**
	 * save Employee Details 
	 * @param employeeForm
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeDO saveEmployee(EmployeeDO employeeDO) throws PSLException;
	
	/**
	 * get Total Employee Details
	 * @param employeeCode 
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public List<EmployeeDO> getEmployeeDetails() throws PSLException;
	
	/**
	 * get  Employee Details
	 * @param employeeCode 
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeDO getEmployee(EmployeeDO domain) throws PSLException;
	
	/**
	 * get Employee Details For WebService
	 * @param EmployeeDO
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeDO getEmployeeForAdmin(EmployeeDO domain) throws PSLException;
	/**
	 * Save Employee Details From WebService
	 * @param EmployeeDO
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeDO saveOrUpdateEmployee(EmployeeDO employeeDO) throws PSLException;
	/**
	 * Delete Employee Details For WebService
	 * @param EmployeeDO
	 * @return EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public void deleteEmployee(EmployeeDO employeeDO) throws PSLException;
}
