package com.psl.emp.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.psl.emp.constant.ApiConstants;
import com.psl.emp.constant.PSLException;
import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.utils.StringUtil;
/**
 * @author mahender_kakkerla
 *
 */
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = PSLException.class)
public class ValidateLogingUserDAOImpl extends BaseDao implements ValidateLogingUserDAO{

	/** The Constant LOGGER. */
	private final static Logger LOGGER = LoggerFactory.getLogger(ValidateLogingUserDAOImpl.class);
	
	@SuppressWarnings("unchecked")
	public EmployeeDO getUserDetails(EmployeeDO domain) throws PSLException {
		LOGGER.debug("ValidateLogingUserDAOImpl::getUserDetails())::Start::");
		List<EmployeeDO> loginDOs = null;
		String[] params = {ApiConstants.EMAILID, 
				ApiConstants.PASSWORD, ApiConstants.EMPTYPE};
		Object[] values = {domain.getEmailId(), domain.getPassword(), domain.getEmpType()};
		loginDOs = (List<EmployeeDO>)getHibernateTemplate()
				.findByNamedQueryAndNamedParam(ApiConstants.QRY_GETUSERDETAILS, 
						params, values);
		LOGGER.debug("ValidateLogingUserDAOImpl::getUserDetails()::END");
		return (!StringUtil.isEmptyColletion(
				loginDOs))?loginDOs.get(0):null;
	}
	
	
	public EmployeeDO saveEmployee(EmployeeDO employeeDO) throws PSLException {

		LOGGER.debug("ValidateLogingUserDAOImpl :: saveEmployee() :: Start --------> ::::::");
		try {

			getHibernateTemplate().saveOrUpdate(employeeDO);
		}

		catch (Exception e) {
			LOGGER.error("Exception Occured in::ValidateLogingUserDAOImpl::saveEmployee() :: " + e);

		}

		LOGGER.debug("ValidateLogingUserDAOImpl :: saveEmployee() :: End --------> ::::::");

		return employeeDO;
	}
	
	@SuppressWarnings("unchecked")
	public List<EmployeeDO> getEmployeeDetails() throws PSLException {
		LOGGER.debug("ValidateLogingUserDAOImpl::getEmployeeDetails())::Start::");
		List<EmployeeDO> empDOs = null;
		
		empDOs = (List<EmployeeDO>)getHibernateTemplate()
				.findByNamedQuery(ApiConstants.QRY_GETEMPDETAILS);
		LOGGER.debug("ValidateLogingUserDAOImpl::getEmployeeDetails()::END");
		return (!StringUtil.isEmptyColletion(
				empDOs))?empDOs:null;
	}
	
	
	@SuppressWarnings("unchecked")
	public EmployeeDO getEmployee(EmployeeDO domain) throws PSLException {
		LOGGER.debug("ValidateLogingUserDAOImpl::getEmployee())::Start::");
		List<EmployeeDO> employeeDOs = null;
		String[] params = {ApiConstants.EMPLOYEECODE,ApiConstants.EMAILID};
		Object[] values = {domain.getEmployeeCode(),domain.getEmailId()};
		employeeDOs = (List<EmployeeDO>)getHibernateTemplate()
				.findByNamedQueryAndNamedParam(ApiConstants.QRY_GETEMPLOYEE, 
						params, values);
		LOGGER.debug("ValidateLogingUserDAOImpl::getEmployee()::END");
		return (!StringUtil.isEmptyColletion(
				employeeDOs))?employeeDOs.get(0):null;
	}
	
	@SuppressWarnings("unchecked")
	public EmployeeDO getEmployeeForAdmin(EmployeeDO domain) throws PSLException{
		LOGGER.debug("ValidateLogingUserDAOImpl::getEmployeeLogoutDetails())::Start::");
		List<EmployeeDO> employeeDOs = null;
		String[] params = {ApiConstants.EMPLOYEECODE};
		Object[] values = {domain.getEmployeeCode()};
		employeeDOs = (List<EmployeeDO>)getHibernateTemplate()
				.findByNamedQueryAndNamedParam(ApiConstants.QRY_GETEMPLOYEEFORADMIN, 
						params, values);
		LOGGER.debug("ValidateLogingUserDAOImpl::getEmployeeLogoutDetails()::END");
		return (!StringUtil.isEmptyColletion(
				employeeDOs))?employeeDOs.get(0):null;
		
	}
	
	public EmployeeDO saveOrUpdateEmployee(EmployeeDO employeeDO) throws PSLException {

		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction tx = null;
		EmployeeDO empDO = null;
		try {
			LOGGER.trace("ValidateLogingUserDAOImpl :: saveOrUpdateEmployee() :: Start --------> ::::::");
			tx = session.beginTransaction();
			empDO = (EmployeeDO) session.merge(employeeDO);

			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			LOGGER.trace("Error occured in ValidateLogingUserDAOImpl :: saveOrUpdateEmployee():", e);

		} finally {
			session.close();
		}
		LOGGER.trace("ValidateLogingUserDAOImpl :: saveOrUpdateEmployee() :: END --------> ::::::");

		return empDO;
	}
	
	public void deleteEmployee(EmployeeDO employeeDO) throws PSLException {
		LOGGER.debug("ValidateLogingUserDAOImpl :: deleteEmployee() :: start --------> ::::::");

		Session session = null;
		try {
			session = getHibernateTemplate().getSessionFactory().openSession();
			if (null != employeeDO.getEmployeeId()) {
				Query q = session
						.createQuery("DELETE FROM com.psl.emp.domain.EmployeeDO ven WHERE ven.employeeId=:empId");
				q.setInteger("empId", employeeDO.getEmployeeId());

				int status = q.executeUpdate();
				LOGGER.debug("Status===" + status);
			}
		} catch (Exception e) {
			LOGGER.error("Exception Occured in::ValidateLogingUserDAOImpl::deleteEmployee() :: " + e);

		} finally {
			closeSession(session);
		}

		LOGGER.debug("ValidateLogingUserDAOImpl :: deleteEmployee() :: End --------> ::::::");
	}

}
