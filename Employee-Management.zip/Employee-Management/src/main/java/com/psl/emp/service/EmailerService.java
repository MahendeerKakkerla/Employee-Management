package com.psl.emp.service;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.psl.emp.constant.EmailException;


/**
 * @author mahender_kakkerla
 *
 */
public interface EmailerService {


/*	public boolean sendMailPlainwithoutAttachment(String to, 
					String cc, String bcc, String sub, String emailMsg) 
					throws IOException, MessagingException, EmailException;*/
	
	public void sendMail(String to, String subject, String body) ;
	 public void sendHtmlEmail(String host, String port,
	            final String userName, final String password, String toAddress,
	            String subject, String message) throws AddressException,
	            MessagingException;
	

}
