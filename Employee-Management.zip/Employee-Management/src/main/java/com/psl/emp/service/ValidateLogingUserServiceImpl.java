package com.psl.emp.service;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.psl.emp.constant.PSLException;
import com.psl.emp.dao.ValidateLogingUserDAO;
import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;
import com.psl.emp.form.EmployeeForm;
import com.psl.emp.ws.mapper.UserObjectMapper;
import com.psl.emp.ws.vo.EmployeeWSDO;
import com.psl.emp.ws.vo.EmployeeWSInput;

/**
 * @author mahender_kakkerla
 *
 */
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = PSLException.class)
public class ValidateLogingUserServiceImpl implements ValidateLogingUserService {

	private static final Logger logger = Logger.getLogger(ValidateLogingUserServiceImpl.class);

	/** The dao offering common saving in transactional tables. */
	private ValidateLogingUserDAO validateLogingUserDAO;

	public ValidateLogingUserDAO getValidateLogingUserDAO() {
		return validateLogingUserDAO;
	}

	public void setValidateLogingUserDAO(ValidateLogingUserDAO validateLogingUserDAO) {
		this.validateLogingUserDAO = validateLogingUserDAO;
	}

	private RestTemplate restTemplate = new RestTemplate();
	private EmployeeWSInput employeeWSInput = null;
	private List<EmployeeWSDO> employeeWSDOList = null;

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getUserDetails(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm getUserDetails(EmployeeForm employeeForm) throws PSLException {
		logger.debug("ValidateLogingUserServiceImpl: getUserDetails method executing start and end ");
		EmployeeDO empDo = new EmployeeDO();
		try {
			BeanUtils.copyProperties(empDo, employeeForm);
			EmployeeDO employeeDo = validateLogingUserDAO.getUserDetails(empDo);
			if (null != employeeDo) {
				BeanUtils.copyProperties(employeeForm, employeeDo);
			} else {
				employeeForm = null;
			}

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return employeeForm;
	}

	
	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#saveEmployee(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm saveEmployee(EmployeeForm employeeForm) throws PSLException {

		EmployeeDO empDo = new EmployeeDO();
		try {
			BeanUtils.copyProperties(empDo, employeeForm);
			Set<EmployeeLogoutTimeDetailsDO> detailDos = empDo.getDetailsDO();
			if (null != detailDos) {
				for (EmployeeLogoutTimeDetailsDO empLoutTime : detailDos) {
					empLoutTime.setHeader(empDo);
				}
			}

			EmployeeDO employeeDo = validateLogingUserDAO.saveEmployee(empDo);
			BeanUtils.copyProperties(employeeForm, employeeDo);

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		return employeeForm;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getEmployeeDetails()
	 */
	public List<EmployeeForm> getEmployeeDetails() throws PSLException {

		List<EmployeeForm> empForms = new ArrayList<EmployeeForm>();
		try {

			List<EmployeeDO> employeeDos = validateLogingUserDAO.getEmployeeDetails();
			if (null != employeeDos) {
				for (EmployeeDO empdo : employeeDos) {
					EmployeeForm empForm = new EmployeeForm();
					BeanUtils.copyProperties(empForm, empdo);
					empForms.add(empForm);
				}

			}

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		return empForms;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getEmployee(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm getEmployee(EmployeeForm employeeForm) throws PSLException {

		try {
			EmployeeDO empDo = new EmployeeDO();
			BeanUtils.copyProperties(empDo, employeeForm);
			EmployeeDO employeeDo = validateLogingUserDAO.getEmployee(empDo);

			if (null != employeeDo) {
				BeanUtils.copyProperties(employeeForm, employeeDo);
			} else {
				employeeForm = null;
			}

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		return employeeForm;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getEmployeeForAdmin(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm getEmployeeForAdmin(EmployeeForm employeeForm) throws PSLException {
		try {
			EmployeeDO empDo = new EmployeeDO();
			BeanUtils.copyProperties(empDo, employeeForm);
			EmployeeDO employeeDo = validateLogingUserDAO.getEmployeeForAdmin(empDo);

			if (null != employeeDo) {
				BeanUtils.copyProperties(employeeForm, employeeDo);
			} else {
				employeeForm = null;
			}

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		return employeeForm;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#checkEmployee(com.psl.emp.form.EmployeeForm)
	 */
	public Boolean checkEmployee(EmployeeForm employeeForm) throws PSLException {

		Boolean isexisted = false;

		try {
			EmployeeDO empDo = new EmployeeDO();
			BeanUtils.copyProperties(empDo, employeeForm);
			EmployeeDO employeeDo = validateLogingUserDAO.getEmployee(empDo);

			if (null != employeeDo) {
				isexisted = true;
			} else {
				isexisted = false;
			}

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		return isexisted;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getEmployeeWSList()
	 */
	public List<EmployeeDO> getEmployeeWSList() throws PSLException {

		List<EmployeeDO> employeeDos = null;

		employeeDos = validateLogingUserDAO.getEmployeeDetails();

		return employeeDos;
	}

	/* Web Service Calls Start */

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getLoginEmployeeDetails(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm getLoginEmployeeDetails(EmployeeForm employeeForm) throws PSLException {
		logger.debug("ValidateLogingUserServiceImpl: getLoginEmployeeDetails method executing start  ");

		try {

			EmployeeWSDO empWSDO = new EmployeeWSDO();
			empWSDO.setEmailId(employeeForm.getEmailId());
			empWSDO.setPassword(employeeForm.getPassword());
			empWSDO.setEmpType(employeeForm.getEmpType());

			employeeWSInput = new EmployeeWSInput();
			employeeWSDOList = new ArrayList<EmployeeWSDO>();
			employeeWSDOList.add(empWSDO);
			employeeWSInput.setEmployeeList(employeeWSDOList);

			// rest Webservice calls
			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/getLoginEmployeeDetails";
			
			EmployeeWSInput output = restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);
			if (null != output) {
				List<EmployeeWSDO> empWSDOList = output.getEmployeeList();
				EmployeeWSDO employeeWSDO = empWSDOList.get(0);

				if (null != employeeWSDO) {
					EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
					BeanUtils.copyProperties(employeeForm, employeeDO);
				} else {
					employeeForm = null;
				}
			} else {
				return null;
			}

		} catch (IllegalAccessException e) {
			e.printStackTrace();
			logger.debug("ValidateLogingUserServiceImpl: getLoginEmployeeDetails getExecption   " + e);
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			logger.debug("ValidateLogingUserServiceImpl: getLoginEmployeeDetails getExecption   " + e);
		}
		logger.debug("ValidateLogingUserServiceImpl: getLoginEmployeeDetails method executing End  ");
		return employeeForm;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getUserWSDetails(com.psl.emp.domain.EmployeeDO)
	 */
	public EmployeeDO getUserWSDetails(EmployeeDO employeeDo) throws PSLException {
		logger.debug("ValidateLogingUserServiceImpl: getUserWSDetails method executing start and end ");
		EmployeeDO employeeExistDo = null;

		employeeExistDo = validateLogingUserDAO.getUserDetails(employeeDo);

		return employeeExistDo;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getEmployeeWSDetails()
	 */
	public List<EmployeeForm> getEmployeeWSDetails() throws PSLException {

		List<EmployeeForm> empForms = new ArrayList<EmployeeForm>();
		try {

			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/getEmployeeWSList";
			EmployeeWSInput output = restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);
			if (null != output) {
				List<EmployeeWSDO> empWSDOList = output.getEmployeeList();
				if (null != empWSDOList) {
					for (EmployeeWSDO empWSDO : empWSDOList) {
						EmployeeForm empForm = UserObjectMapper.copyToEmployeeForm(empWSDO, null);
						empForms.add(empForm);
					}

				}

			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return empForms;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#getWSEmployeeForAdmin(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm getWSEmployeeForAdmin(EmployeeForm employeeForm) throws PSLException {

		logger.debug("ValidateLogingUserServiceImpl: getWSEmployeeForAdmin method executing start  ");

		try {

			EmployeeWSDO empWSDO = UserObjectMapper.copyFormToEmployeeWSDO(employeeForm);

			employeeWSInput = new EmployeeWSInput();
			employeeWSDOList = new ArrayList<EmployeeWSDO>();
			employeeWSDOList.add(empWSDO);
			employeeWSInput.setEmployeeList(employeeWSDOList);

			// rest Webservice calls
			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/getWSEmployeeForAdmin";
			EmployeeWSInput output = restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);
			if (null != output) {
				List<EmployeeWSDO> empWSDOList = output.getEmployeeList();
				EmployeeWSDO employeeWSDO = empWSDOList.get(0);

				if (null != employeeWSDO) {
					employeeForm = UserObjectMapper.copyToEmployeeForm(employeeWSDO, employeeForm);

				} else {
					employeeForm = null;
				}
			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("ValidateLogingUserServiceImpl: getLoginEmployeeDetails getExecption   " + e);
		}
		logger.debug("ValidateLogingUserServiceImpl: getLoginEmployeeDetails method executing End  ");
		return employeeForm;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#checkWSEmployee(com.psl.emp.form.EmployeeForm)
	 */
	public Boolean checkWSEmployee(EmployeeForm employeeForm) throws PSLException {

		Boolean isexisted = false;

		try {

			logger.debug("ValidateLogingUserServiceImpl: checkWSEmployee method executing start  ");

			EmployeeWSDO empWSDO = UserObjectMapper.copyFormToEmployeeWSDO(employeeForm);

			employeeWSInput = new EmployeeWSInput();
			employeeWSDOList = new ArrayList<EmployeeWSDO>();
			employeeWSDOList.add(empWSDO);
			employeeWSInput.setEmployeeList(employeeWSDOList);

			// rest Webservice calls
			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/checkWSEmployee";
			EmployeeWSInput output = restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);
			if (null != output) {
				List<EmployeeWSDO> empWSDOList = output.getEmployeeList();
				EmployeeWSDO employeeWSDO = empWSDOList.get(0);

				if (null != employeeWSDO) {
					employeeForm = UserObjectMapper.copyToEmployeeForm(employeeWSDO, employeeForm);
					isexisted = true;
				} else {
					employeeForm = null;
					isexisted = false;
				}
			} else {

				isexisted = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.debug("ValidateLogingUserServiceImpl: checkWSEmployee method executing End  ");
		return isexisted;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#saveWSEmployee(com.psl.emp.form.EmployeeForm)
	 */
	public EmployeeForm saveWSEmployee(EmployeeForm employeeForm) throws PSLException {

		logger.debug("ValidateLogingUserServiceImpl: saveWSEmployee method executing start  ");

		try {

			EmployeeWSDO empWSDO = UserObjectMapper.copyFormToEmployeeWSDO(employeeForm);

			employeeWSInput = new EmployeeWSInput();
			employeeWSDOList = new ArrayList<EmployeeWSDO>();
			employeeWSDOList.add(empWSDO);
			employeeWSInput.setEmployeeList(employeeWSDOList);

			// rest Webservice calls
			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/saveWSEmployee";
			EmployeeWSInput output = restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);
			if (null != output) {
				List<EmployeeWSDO> empWSDOList = output.getEmployeeList();
				EmployeeWSDO employeeWSDO = empWSDOList.get(0);

				if (null != employeeWSDO) {
					employeeForm = UserObjectMapper.copyToEmployeeForm(employeeWSDO, employeeForm);

				} else {
					employeeForm = null;
				}
			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("ValidateLogingUserServiceImpl: saveWSEmployee getExecption   " + e);
		}
		logger.debug("ValidateLogingUserServiceImpl: saveWSEmployee method executing End  ");
		return employeeForm;
	}

	/* 
	 * @see com.psl.emp.service.ValidateLogingUserService#deleteEmployee(com.psl.emp.form.EmployeeForm)
	 */
	public void deleteEmployee(EmployeeForm employeeForm) throws PSLException {

		logger.debug("ValidateLogingUserServiceImpl: deleteEmployee method executing start  ");

		try {

			EmployeeWSDO empWSDO = UserObjectMapper.copyFormToEmployeeWSDO(employeeForm);

			employeeWSInput = new EmployeeWSInput();
			employeeWSDOList = new ArrayList<EmployeeWSDO>();
			employeeWSDOList.add(empWSDO);
			employeeWSInput.setEmployeeList(employeeWSDOList);

			// rest Webservice calls
			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/deleteEmployee";
			restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("ValidateLogingUserServiceImpl: deleteEmployee getExecption   " + e);
		}
		logger.debug("ValidateLogingUserServiceImpl: deleteEmployee method executing End  ");

	}
	
	public void logOutNFC(EmployeeForm employeeForm) throws PSLException {

		logger.debug("ValidateLogingUserServiceImpl: logOutNFC method executing start  ");

		try {

			EmployeeWSDO empWSDO = UserObjectMapper.copyFormToEmployeeWSDO(employeeForm);

			employeeWSInput = new EmployeeWSInput();
			employeeWSDOList = new ArrayList<EmployeeWSDO>();
			employeeWSDOList.add(empWSDO);
			employeeWSInput.setEmployeeList(employeeWSDOList);

			// rest Webservice calls
			final String uri = "http://10.222.129.75:8080/EmployeeManagement-1.0-SNAPSHOT/ws/logOutNFC";
			restTemplate.postForObject(uri, employeeWSInput, EmployeeWSInput.class);

		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("ValidateLogingUserServiceImpl: logOutNFC getExecption   " + e);
		}
		logger.debug("ValidateLogingUserServiceImpl: logOutNFC method executing End  ");

	}

}
