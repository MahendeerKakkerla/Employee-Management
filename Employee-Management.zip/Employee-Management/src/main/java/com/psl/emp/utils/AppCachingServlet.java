package com.psl.emp.utils;


import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;


/**
 * @author mahender_kakkerla
 *
 */
public class AppCachingServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger
			.getLogger(AppCachingServlet.class);
	public static String appPath;

	public void init(ServletConfig config) throws ServletException {
		try {
			logger.debug("Data caching started.");
			System.out.println("AppCachingServlet   ----------init  *******************");
			loadDriver();
			SpringUtil.getSpringUtil();
			System.out.println("AppCachingServlet   ---------- application context  *******************");
			logger.debug("Data caching completed.");
		} catch (Exception e) {
			logger.error("",e);
		}
	}

	private void loadDriver() throws Exception {
		String driver = "net.sourceforge.jtds.jdbc.Driver";
		Class.forName(driver);
	}
}
