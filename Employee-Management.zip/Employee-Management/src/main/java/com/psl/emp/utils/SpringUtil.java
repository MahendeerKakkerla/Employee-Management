package com.psl.emp.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author mahender_kakkerla
 *
 */
public class SpringUtil {

	private ApplicationContext applicationContext;
	private static SpringUtil springUtil = new SpringUtil();

	private SpringUtil() {
		try {
			applicationContext = new ClassPathXmlApplicationContext(
					"applicationContext.xml");
		} catch (BeansException e) {
			e.printStackTrace();
		}

	}

	public Object getService(String service) {
		return applicationContext.getBean(service);
	}

	public static SpringUtil getSpringUtil() {
		synchronized (SpringUtil.class) {
			if (springUtil == null) {
				springUtil = new SpringUtil();
			}
		}
		return springUtil;
	}
}