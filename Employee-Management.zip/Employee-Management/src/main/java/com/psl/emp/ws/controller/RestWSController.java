package com.psl.emp.ws.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.jws.WebService;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.psl.emp.dao.ValidateLogingUserDAO;
import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;
import com.psl.emp.service.ValidateLogingUserService;
import com.psl.emp.utils.SpringUtil;
import com.psl.emp.ws.mapper.UserObjectMapper;
import com.psl.emp.ws.vo.EmployeeWSDO;
import com.psl.emp.ws.vo.EmployeeWSInput;

/**
 * @author mahender_kakkerla
 *
 */
@WebService
@RestController
public class RestWSController {

private	ValidateLogingUserService validateLogingUserService = (ValidateLogingUserService) SpringUtil.getSpringUtil()
			.getService("validateLogingUserService");
private	ValidateLogingUserDAO validateLogingUserDAO = (ValidateLogingUserDAO) SpringUtil.getSpringUtil()
.getService("validateLogingUserDAO");
	
/**
 * This method is used to get all employees 
 * @param employeeWSInput
 * @return EmployeeDO List
 */
	@RequestMapping(value = "/getEmployeeWSList", method = RequestMethod.POST)
	public EmployeeWSInput getEmployeeWSList(@RequestBody EmployeeWSInput employeeWSInput) {
		List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
		ValidateLogingUserService validateLogingUserService = (ValidateLogingUserService) SpringUtil.getSpringUtil()
				.getService("validateLogingUserService");
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		
		
	
		
		
		List<EmployeeDO> employeeDos = validateLogingUserService.getEmployeeWSList();
		
		if(null != employeeDos){
			for(EmployeeDO empdo: employeeDos){
				
				EmployeeWSDO employeeWSDO1 =UserObjectMapper.copyToEmployeeWSDO(empdo);
				employeeWSList.add(employeeWSDO1);
				
			}
			employeeWSoutput.setEmployeeList(employeeWSList);
			
		}else{
			return null;
		}
		return employeeWSoutput;
	}
	
	/**
	 * This method is used to check employee login details
	 * @param employeeWSInput
	 * @return EmployeeDO List
	 */
	@RequestMapping(value = "/getLoginEmployeeDetails", method = RequestMethod.POST)
	public EmployeeWSInput getLoginEmployeeDetails(@RequestBody EmployeeWSInput employeeWSInput) {
		
		
	
		

		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList = employeeWSInput.getEmployeeList();
		if (null != employeeWSList && employeeWSList.size() > 0) {

			EmployeeWSDO employeeWSDO = employeeWSList.get(0);
			EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
			EmployeeDO employeeExitDO = validateLogingUserService.getUserWSDetails(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSOutputList.add(employeeExistWSDO);
			} else {
				return null;
			}
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSOutputList);

		return employeeWSoutput;
	}
	
	
	
	/**
	 * This method is used to get employee for admin
	 * @param employeeWSInput
	 * @return EmployeeDO List
	 */
	@RequestMapping(value = "/getWSEmployeeForAdmin", method = RequestMethod.POST)
	public EmployeeWSInput getWSEmployeeForAdmin(@RequestBody EmployeeWSInput employeeWSInput) {
		
		
		

		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList = employeeWSInput.getEmployeeList();
		if (null != employeeWSList && employeeWSList.size() > 0) {

			EmployeeWSDO employeeWSDO = employeeWSList.get(0);
			EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
			EmployeeDO employeeExitDO = validateLogingUserDAO.getEmployeeForAdmin(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSOutputList.add(employeeExistWSDO);
			} else {
				return null;
			}
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSOutputList);

		return employeeWSoutput;
	}
	
	
	/**
	 * This method is used to check employee existed or not
	 * @param employeeWSInput
	 * @return EmployeeDO List
	 */

	@RequestMapping(value = "/checkWSEmployee", method = RequestMethod.POST)
	public EmployeeWSInput checkWSEmployee(@RequestBody EmployeeWSInput employeeWSInput) {
		
	
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList = employeeWSInput.getEmployeeList();
		if (null != employeeWSList && employeeWSList.size() > 0) {

			EmployeeWSDO employeeWSDO = employeeWSList.get(0);
			EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
			EmployeeDO employeeExitDO = validateLogingUserDAO.getEmployee(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSOutputList.add(employeeExistWSDO);
			} else {
				return null;
			}
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSOutputList);

		return employeeWSoutput;
	}
	
	
	/**
	 * This method is used to save or update employee
	 * @param employeeWSInput
	 * @return EmployeeDO List
	 */
	@RequestMapping(value = "/saveWSEmployee", method = RequestMethod.POST)
	public EmployeeWSInput saveWSEmployee(@RequestBody EmployeeWSInput employeeWSInput) {
		
	

		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList = employeeWSInput.getEmployeeList();
		if (null != employeeWSList && employeeWSList.size() > 0) {

			EmployeeWSDO employeeWSDO = employeeWSList.get(0);
			EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
			if (employeeDO.getEmployeeId() != null) {
				EmployeeDO tempEmp = validateLogingUserDAO.getEmployeeForAdmin(employeeDO);

				employeeDO = checkChildsToSave(tempEmp, employeeDO);

			}
			EmployeeDO employeeExitDO = validateLogingUserDAO.saveOrUpdateEmployee(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSOutputList.add(employeeExistWSDO);
			} else {
				return null;
			}
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSOutputList);

		return employeeWSoutput;
	}
	
	/**
	 * This method is used to delete existing employee
	 * @param employeeWSInput
	 * @return EmployeeDO List
	 */
	@RequestMapping(value = "/deleteEmployee", method = RequestMethod.POST)
	public EmployeeWSInput deleteEmployee(@RequestBody EmployeeWSInput employeeWSInput) {
		
	
		

		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList = employeeWSInput.getEmployeeList();
		if (null != employeeWSList && employeeWSList.size() > 0) {

			EmployeeWSDO employeeWSDO = employeeWSList.get(0);
			EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
			 validateLogingUserDAO.deleteEmployee(employeeDO);
			
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSOutputList);

		return employeeWSoutput;
	}
	
	
	/**
	 * This method is used to get employee for admin
	 * @param employeeWSInput
	 * @return EmployeeDO List
	 */
	@RequestMapping(value = "/logOutNFC", method = RequestMethod.POST)
	public EmployeeWSInput logOutNFC(@RequestBody EmployeeWSInput employeeWSInput) {
		
		
		

		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList = employeeWSInput.getEmployeeList();
		if (null != employeeWSList && employeeWSList.size() > 0) {

			EmployeeWSDO employeeWSDO = employeeWSList.get(0);
			EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO);
			EmployeeDO employeeExitDO = validateLogingUserDAO.getEmployeeForAdmin(employeeDO);
			employeeExitDO.setLogoutTime(new Date());
			employeeExitDO.setCreationDate(new Date());
			Set<EmployeeLogoutTimeDetailsDO> setDetailDos = employeeExitDO.getDetailsDO();
			if(null != setDetailDos){
				EmployeeLogoutTimeDetailsDO employeeLogoutTimeDetailsDO = new EmployeeLogoutTimeDetailsDO();

				SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
				SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");

				String dateAsString = dateFormatter.format(new Date());
				String timeAsString = timeFormatter.format(new Date());

				employeeLogoutTimeDetailsDO.setOutDate(dateAsString);
				employeeLogoutTimeDetailsDO.setOutTime(timeAsString);
				employeeLogoutTimeDetailsDO.setDayName(LocalDate.now().getDayOfWeek().name());
				employeeLogoutTimeDetailsDO.setHeader(employeeExitDO);
				setDetailDos.add(employeeLogoutTimeDetailsDO);
				employeeExitDO.setDetailsDO(setDetailDos);
				 employeeExitDO = validateLogingUserDAO.saveOrUpdateEmployee(employeeExitDO);
			}
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSOutputList.add(employeeExistWSDO);
			} else {
				return null;
			}
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSOutputList);

		return employeeWSoutput;
	}
	
	private EmployeeDO checkChildsToSave(EmployeeDO existingEmployeeDO, EmployeeDO newEmployeeDO) {
		Set<EmployeeLogoutTimeDetailsDO> existingDetailsDOs = existingEmployeeDO.getDetailsDO();
		Set<EmployeeLogoutTimeDetailsDO> currentDetailsDOs = newEmployeeDO.getDetailsDO();
		if (null != existingDetailsDOs && null != currentDetailsDOs) {

			List<Integer> detailIds = new ArrayList<Integer>();

			for (EmployeeLogoutTimeDetailsDO newdetailDO : currentDetailsDOs) {
				if (null != newdetailDO.getDetailId()) {
					detailIds.add(newdetailDO.getDetailId());
				}

			}
			for (EmployeeLogoutTimeDetailsDO existdetailDO : existingDetailsDOs) {
				if (detailIds.contains(existdetailDO.getDetailId())) {

				} else {
					currentDetailsDOs.add(existdetailDO);
				}
			}
			newEmployeeDO.setDetailsDO(currentDetailsDOs);
		}

		if (null == currentDetailsDOs && null != existingDetailsDOs) {
			newEmployeeDO.setDetailsDO(existingDetailsDOs);
		}

		return newEmployeeDO;

	}
	
}
