package com.psl.emp.ws.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;
import com.psl.emp.form.EmployeeForm;
import com.psl.emp.ws.vo.EmployeeLogoutTimeDetailsWSDO;
import com.psl.emp.ws.vo.EmployeeWSDO;

/**
 * @author mahender_kakkerla
 *
 */
public class UserObjectMapper {
	
	private static  Logger logger = LoggerFactory
			.getLogger(EmployeeWSDO.class);
	private static String DDMMYYYYHHMMSS_SLASH_FORMAT = "dd/MM/yyyy HH:mm:ss";

	
	/*copyToEmployeeWSDO   start*/
	private static EmployeeWSDO employeeWSDO = null;
	public static EmployeeWSDO copyToEmployeeWSDO(EmployeeDO employeeDO) {

		if (null == employeeDO) {
			return null;
		}

		 employeeWSDO = new EmployeeWSDO();
		employeeWSDO.setEmployeeId(employeeDO.getEmployeeId());
		employeeWSDO.setFirstName(employeeDO.getFirstName());
		employeeWSDO.setLastName(employeeDO.getLastName());
		employeeWSDO.setEmployeeCode(employeeDO.getEmployeeCode());
		employeeWSDO.setPhone(employeeDO.getPhone());
		employeeWSDO.setDesignation(employeeDO.getDesignation());
		employeeWSDO.setDepartment(employeeDO.getDepartment());
		employeeWSDO.setCity(employeeDO.getCity());
		employeeWSDO.setOffice(employeeDO.getOffice());
		employeeWSDO.setEmailId(employeeDO.getEmailId());
		employeeWSDO.setManagerEmailId(employeeDO.getManagerEmailId());
		if (null != employeeDO.getLogoutTime()) {
			employeeWSDO.setLogoutTime(dateToStringFormatter(employeeDO.getLogoutTime()));
		}

		employeeWSDO.setCreatedby(employeeDO.getCreatedby());
		if (null != employeeDO.getCreationDate()) {
			employeeWSDO.setCreationDate(dateToStringFormatter(employeeDO.getCreationDate()));
		}

		employeeWSDO.setEmpStatus(employeeDO.getEmpStatus());
		employeeWSDO.setPassword(employeeDO.getPassword());
		employeeWSDO.setEmpType(employeeDO.getEmpType());
		employeeWSDO.setAddress1(employeeDO.getAddress1());
		employeeWSDO.setAddress2(employeeDO.getAddress2());
		employeeWSDO.setState(employeeDO.getState());
		employeeWSDO.setPincode(employeeDO.getPincode());
		employeeWSDO.setDetailsDO(copyToEmployeeLogoutTimeDetailsWSDO(employeeDO.getDetailsDO()));

		return employeeWSDO;
	}

	private static List<EmployeeLogoutTimeDetailsWSDO> copyToEmployeeLogoutTimeDetailsWSDO(
			Collection<EmployeeLogoutTimeDetailsDO> employeeLogoutTimeDetailsDOs) {
		if (null == employeeLogoutTimeDetailsDOs) {
			return null;
		}
		List<EmployeeLogoutTimeDetailsWSDO> employeeLogoutTimeDetailsWSDOList = new ArrayList<EmployeeLogoutTimeDetailsWSDO>();
		for (EmployeeLogoutTimeDetailsDO detailsDo : employeeLogoutTimeDetailsDOs) {
			EmployeeLogoutTimeDetailsWSDO detailsWSDo = new EmployeeLogoutTimeDetailsWSDO();

			detailsWSDo.setDetailId(detailsDo.getDetailId());
			detailsWSDo.setDayName(detailsDo.getDayName());
			detailsWSDo.setOutDate(detailsDo.getOutDate());
			detailsWSDo.setOutTime(detailsDo.getOutTime());
			if(null != detailsDo.getHeader()){
				detailsWSDo.setHeader(detailsDo.getHeader().getEmployeeId());	
			}else{
				detailsWSDo.setHeader(employeeWSDO.getEmployeeId());
			}
			
			employeeLogoutTimeDetailsWSDOList.add(detailsWSDo);
		}

		return employeeLogoutTimeDetailsWSDOList;
	}
	
	/*copyToEmployeeWSDO   end*/
	
	
	
	/*copyFormToEmployeeWSDO   start*/
	public static EmployeeWSDO copyFormToEmployeeWSDO(EmployeeForm employeeForm) {

		if (null == employeeForm) {
			return null;
		}

		 employeeWSDO = new EmployeeWSDO();
		employeeWSDO.setEmployeeId(employeeForm.getEmployeeId());
		employeeWSDO.setFirstName(employeeForm.getFirstName());
		employeeWSDO.setLastName(employeeForm.getLastName());
		employeeWSDO.setEmployeeCode(employeeForm.getEmployeeCode());
		employeeWSDO.setPhone(employeeForm.getPhone());
		employeeWSDO.setDesignation(employeeForm.getDesignation());
		employeeWSDO.setDepartment(employeeForm.getDepartment());
		employeeWSDO.setCity(employeeForm.getCity());
		employeeWSDO.setOffice(employeeForm.getOffice());
		employeeWSDO.setEmailId(employeeForm.getEmailId());
		employeeWSDO.setManagerEmailId(employeeForm.getManagerEmailId());
		if (null != employeeForm.getLogoutTime()) {
			employeeWSDO.setLogoutTime(dateToStringFormatter(employeeForm.getLogoutTime()));
		}

		employeeWSDO.setCreatedby(employeeForm.getCreatedby());
		if (null != employeeForm.getCreationDate()) {
			employeeWSDO.setCreationDate(dateToStringFormatter(employeeForm.getCreationDate()));
		}

		employeeWSDO.setEmpStatus(employeeForm.getEmpStatus());
		employeeWSDO.setPassword(employeeForm.getPassword());
		employeeWSDO.setEmpType(employeeForm.getEmpType());
		employeeWSDO.setAddress1(employeeForm.getAddress1());
		employeeWSDO.setAddress2(employeeForm.getAddress2());
		employeeWSDO.setState(employeeForm.getState());
		employeeWSDO.setPincode(employeeForm.getPincode());
		employeeWSDO.setDetailsDO(copyToEmployeeLogoutTimeDetailsWSDO(employeeForm.getDetailsDO()));

		return employeeWSDO;
	}
	/*copyFormToEmployeeWSDO   end*/
	
	
	
	/*copyToEmployeeDO   start*/
	private static EmployeeDO employeeDO = null;

	public static EmployeeDO copyToEmployeeDO(EmployeeWSDO employeeWSDO) {

		if (null == employeeWSDO) {
			return null;
		}

		employeeDO = new EmployeeDO();
		employeeDO.setEmployeeId(employeeWSDO.getEmployeeId());
		employeeDO.setFirstName(employeeWSDO.getFirstName());
		employeeDO.setLastName(employeeWSDO.getLastName());
		employeeDO.setEmployeeCode(employeeWSDO.getEmployeeCode());
		employeeDO.setPhone(employeeWSDO.getPhone());
		employeeDO.setDesignation(employeeWSDO.getDesignation());
		employeeDO.setDepartment(employeeWSDO.getDepartment());
		employeeDO.setCity(employeeWSDO.getCity());
		employeeDO.setOffice(employeeWSDO.getOffice());
		employeeDO.setEmailId(employeeWSDO.getEmailId());
		employeeDO.setManagerEmailId(employeeWSDO.getManagerEmailId());
		if (null != employeeWSDO.getLogoutTime()) {
			employeeDO.setLogoutTime(stringToDateFormatter(employeeWSDO.getLogoutTime()));
		}

		employeeDO.setCreatedby(employeeWSDO.getCreatedby());
		if (null != employeeWSDO.getCreationDate()) {
			employeeDO.setCreationDate(stringToDateFormatter(employeeWSDO.getCreationDate()));
		}

		employeeDO.setEmpStatus(employeeWSDO.getEmpStatus());
		employeeDO.setPassword(employeeWSDO.getPassword());
		employeeDO.setEmpType(employeeWSDO.getEmpType());
		employeeDO.setAddress1(employeeWSDO.getAddress1());
		employeeDO.setAddress2(employeeWSDO.getAddress2());
		employeeDO.setState(employeeWSDO.getState());
		employeeDO.setPincode(employeeWSDO.getPincode());
		employeeDO.setDetailsDO(copyToEmployeeLogoutTimeDetailsDO(employeeWSDO.getDetailsDO()));

		return employeeDO;
	}

	private static Set<EmployeeLogoutTimeDetailsDO> copyToEmployeeLogoutTimeDetailsDO(
			Collection<EmployeeLogoutTimeDetailsWSDO> employeeLogoutTimeDetailsWSDOs) {
		if (null == employeeLogoutTimeDetailsWSDOs) {
			return null;
		}
		Set<EmployeeLogoutTimeDetailsDO> employeeLogoutTimeDetailsDOList = new HashSet<EmployeeLogoutTimeDetailsDO>();
		for (EmployeeLogoutTimeDetailsWSDO detailsWSDo : employeeLogoutTimeDetailsWSDOs) {
			EmployeeLogoutTimeDetailsDO detailsDo = new EmployeeLogoutTimeDetailsDO();

			detailsDo.setDetailId(detailsWSDo.getDetailId());
			detailsDo.setDayName(detailsWSDo.getDayName());
			detailsDo.setOutDate(detailsWSDo.getOutDate());
			detailsDo.setOutTime(detailsWSDo.getOutTime());
			detailsDo.setHeader(employeeDO);
			employeeLogoutTimeDetailsDOList.add(detailsDo);
		}

		return employeeLogoutTimeDetailsDOList;
	}
	
	/*copyToEmployeeDO   end*/
	
	
	
	
	
	
	
	
	
	/*copyToEmployeeForm   start*/
	private static EmployeeForm employeeForm1 = null;

	public static EmployeeForm copyToEmployeeForm(EmployeeWSDO employeeWSDO, EmployeeForm employeeForm) {

		if (null == employeeWSDO) {
			return null;
		}

		if(null == employeeForm){
			employeeForm = new EmployeeForm();
		}
		employeeForm.setEmployeeId(employeeWSDO.getEmployeeId());
		employeeForm.setFirstName(employeeWSDO.getFirstName());
		employeeForm.setLastName(employeeWSDO.getLastName());
		employeeForm.setEmployeeCode(employeeWSDO.getEmployeeCode());
		employeeForm.setPhone(employeeWSDO.getPhone());
		employeeForm.setDesignation(employeeWSDO.getDesignation());
		employeeForm.setDepartment(employeeWSDO.getDepartment());
		employeeForm.setCity(employeeWSDO.getCity());
		employeeForm.setOffice(employeeWSDO.getOffice());
		employeeForm.setEmailId(employeeWSDO.getEmailId());
		employeeForm.setManagerEmailId(employeeWSDO.getManagerEmailId());
		if (null != employeeWSDO.getLogoutTime()) {
			employeeForm.setLogoutTime(stringToDateFormatter(employeeWSDO.getLogoutTime()));
		}

		employeeForm.setCreatedby(employeeWSDO.getCreatedby());
		if (null != employeeWSDO.getCreationDate()) {
			employeeForm.setCreationDate(stringToDateFormatter(employeeWSDO.getCreationDate()));
		}

		employeeForm.setEmpStatus(employeeWSDO.getEmpStatus());
		employeeForm.setPassword(employeeWSDO.getPassword());
		employeeForm.setEmpType(employeeWSDO.getEmpType());
		employeeForm.setAddress1(employeeWSDO.getAddress1());
		employeeForm.setAddress2(employeeWSDO.getAddress2());
		employeeForm.setState(employeeWSDO.getState());
		employeeForm.setPincode(employeeWSDO.getPincode());
		employeeForm1 = employeeForm;
		employeeForm.setDetailsDO(copyToEmployeeLogoutTimeDetailsDOForm(employeeWSDO.getDetailsDO()));

		return employeeForm;
	}

	private static Set<EmployeeLogoutTimeDetailsDO> copyToEmployeeLogoutTimeDetailsDOForm(
			Collection<EmployeeLogoutTimeDetailsWSDO> employeeLogoutTimeDetailsWSDOs) {
		if (null == employeeLogoutTimeDetailsWSDOs) {
			return null;
		}
		Set<EmployeeLogoutTimeDetailsDO> employeeLogoutTimeDetailsDOList = new HashSet<EmployeeLogoutTimeDetailsDO>();
		for (EmployeeLogoutTimeDetailsWSDO detailsWSDo : employeeLogoutTimeDetailsWSDOs) {
			EmployeeLogoutTimeDetailsDO detailsDo = new EmployeeLogoutTimeDetailsDO();

			detailsDo.setDetailId(detailsWSDo.getDetailId());
			detailsDo.setDayName(detailsWSDo.getDayName());
			detailsDo.setOutDate(detailsWSDo.getOutDate());
			detailsDo.setOutTime(detailsWSDo.getOutTime());

			employeeDO = new EmployeeDO();
			employeeDO.setEmployeeId(employeeForm1.getEmployeeId());
			employeeDO.setFirstName(employeeForm1.getFirstName());
			employeeDO.setLastName(employeeForm1.getLastName());
			employeeDO.setEmployeeCode(employeeForm1.getEmployeeCode());
			employeeDO.setPhone(employeeForm1.getPhone());
			employeeDO.setDesignation(employeeForm1.getDesignation());
			employeeDO.setDepartment(employeeForm1.getDepartment());
			employeeDO.setCity(employeeForm1.getCity());
			employeeDO.setOffice(employeeForm1.getOffice());
			employeeDO.setEmailId(employeeForm1.getEmailId());
			employeeDO.setManagerEmailId(employeeForm1.getManagerEmailId());
			if (null != employeeForm1.getLogoutTime()) {
				employeeDO.setLogoutTime((employeeForm1.getLogoutTime()));
			}

			employeeDO.setCreatedby(employeeForm1.getCreatedby());
			if (null != employeeForm1.getCreationDate()) {
				employeeDO.setCreationDate((employeeForm1.getCreationDate()));
			}

			employeeDO.setEmpStatus(employeeForm1.getEmpStatus());
			employeeDO.setPassword(employeeForm1.getPassword());
			employeeDO.setEmpType(employeeForm1.getEmpType());
			employeeDO.setAddress1(employeeForm1.getAddress1());
			employeeDO.setAddress2(employeeForm1.getAddress2());
			employeeDO.setState(employeeForm1.getState());
			employeeDO.setPincode(employeeForm1.getPincode());

			detailsDo.setHeader(employeeDO);
			employeeLogoutTimeDetailsDOList.add(detailsDo);
		}

		return employeeLogoutTimeDetailsDOList;
	}
	/*copyToEmployeeForm   end*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * String to date formatter.
	 * 
	 * @param sourceDate
	 *            the source date
	 * @param formatter
	 *            the formatter
	 * @return the date
	 * @throws ParseException
	 *             the parse exception
	 */
	public static Date stringToDateFormatter(String sourceDate) {

		Date convertedDate = null;
		SimpleDateFormat sdfOutput = new SimpleDateFormat(DDMMYYYYHHMMSS_SLASH_FORMAT);
		try {
			convertedDate = sdfOutput.parse(sourceDate);
		} catch (ParseException e) {
			logger.error("UserObjectMapper::stringToDateFormatter::error " ,e);
		}
		return convertedDate;
	}
	public static String dateToStringFormatter(Date sourceDate) {
		String convertedDateStr = null;
		SimpleDateFormat sdfOutput = new SimpleDateFormat(DDMMYYYYHHMMSS_SLASH_FORMAT);
		try {
			convertedDateStr = sdfOutput.format(sourceDate);
		} catch (Exception e) {
			logger.error("UserObjectMapper::dateToStringFormatter::error " ,e);
		}
		return convertedDateStr;
	}
}
