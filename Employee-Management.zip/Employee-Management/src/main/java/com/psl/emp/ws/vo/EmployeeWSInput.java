package com.psl.emp.ws.vo;

import java.util.List;

import com.psl.emp.domain.EmployeeDO;
/**
 * @author Mahender Kakkerla
 *
 */
public class EmployeeWSInput {
	/*
	 * THis <code> holds employeeList input/output for web service
	 */
	private List<EmployeeWSDO> employeeList;
	private String userName = "";
	private String password = "";
	private String errorMsg = "";

	public List<EmployeeWSDO> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<EmployeeWSDO> employeeList) {
		this.employeeList = employeeList;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	
	

}
