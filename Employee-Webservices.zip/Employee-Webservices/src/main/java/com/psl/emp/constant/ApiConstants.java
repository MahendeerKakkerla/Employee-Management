package com.psl.emp.constant;

/**
 * @author mahender_kakkerla
 *
 */
public interface ApiConstants {

	
	String USER_NAME = "userName";
	String PASSWORD = "password";
	String EMPTYPE = "empType";
	String EMPLOYEECODE = "employeeCode";
	String EMAILID = "emailId";
	
	String QRY_GETUSERDETAILS = "getUserDetails";
	String QRY_GETEMPDETAILS = "getEmpDetails";
	String QRY_GETEMPLOYEE = "getEmployee";
	String QRY_GETEMPLOYEEFORADMIN = "getEmployeeForAdmin";
	
	 String SUCCESS = "success";
	 String FAILURE = "failure";
	 String INPUT = "input";
	 String LOGIN = "login";
	
	 String QRY_GETEMPLOYEELOGIN = "getEmployeeLogin";
	 String QRY_GETTOTALEMPDETAILS = "getTotalEmpDetails";
}
