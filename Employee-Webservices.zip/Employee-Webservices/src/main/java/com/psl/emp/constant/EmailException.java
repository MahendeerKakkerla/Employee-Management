package com.psl.emp.constant;


/**
 * @author mahender_kakkerla
 *
 */
public class EmailException extends Exception {

	private static final long serialVersionUID = 1L;

	public EmailException() {
	}
	public EmailException(String err) {
		
	}

}
