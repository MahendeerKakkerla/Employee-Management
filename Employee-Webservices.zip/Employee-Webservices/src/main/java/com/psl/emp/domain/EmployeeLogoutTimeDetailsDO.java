package com.psl.emp.domain;

/**
 * @author mahender_kakkerla
 *
 */
public class EmployeeLogoutTimeDetailsDO {
	 private static final long serialVersionUID = -473562596852452021L;
	 
	 private Integer detailId;
	    private String outDate;
	    private String outTime;
	    private String dayName;
	   
	    private EmployeeDO header;

		public Integer getDetailId() {
			return detailId;
		}

		public void setDetailId(Integer detailId) {
			this.detailId = detailId;
		}

		public String getOutDate() {
			return outDate;
		}

		public void setOutDate(String outDate) {
			this.outDate = outDate;
		}

		public String getOutTime() {
			return outTime;
		}

		public void setOutTime(String outTime) {
			this.outTime = outTime;
		}

		public String getDayName() {
			return dayName;
		}

		public void setDayName(String dayName) {
			this.dayName = dayName;
		}

		public EmployeeDO getHeader() {
			return header;
		}

		public void setHeader(EmployeeDO header) {
			this.header = header;
		}
	    
	    
	    

}
