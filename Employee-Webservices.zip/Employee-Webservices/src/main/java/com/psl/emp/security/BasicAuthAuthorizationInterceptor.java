package com.psl.emp.security;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.cxf.binding.soap.interceptor.SoapHeaderInterceptor;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxrs.ext.MessageContext;
import org.apache.cxf.jaxrs.ext.MessageContextImpl;
import org.apache.cxf.jaxrs.impl.MetadataMap;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.transport.Conduit;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.apache.cxf.ws.addressing.EndpointReferenceType;
import org.apache.log4j.Logger;

import com.psl.emp.utils.SpringUtils;
import com.psl.emp.webService.RESTEmployeeService;



public class BasicAuthAuthorizationInterceptor extends SoapHeaderInterceptor {

	@Context
	private MessageContext messageContext;

	protected boolean DEBUG = true;

	public static final String REALM = "REMITT Services";



	protected Logger log = Logger
			.getLogger(BasicAuthAuthorizationInterceptor.class);

	private static final char[] HEX_CHARS = { '0', '1', '2', '3', '4', '5',
			'6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', };

	
	private static Map<String, String> users = null;

	private static Long lastCached = null;

	private static Long MAX_CACHE_AGE_IN_MS = 5 * 60 * 1000L; // 5 min

	
	public void setUsers(Map<String, String> u) {
		users = u;
	}

	private RESTEmployeeService RESTEmployeeServiceImpl = (RESTEmployeeService)SpringUtils.ctx.getBean(RESTEmployeeService.class);
	protected void loadUsers() {
		debug("BasicAuthAuthorizationInterceptor.loadUsers() called");
		if (lastCached == null
				|| System.currentTimeMillis() - lastCached > MAX_CACHE_AGE_IN_MS) {
			lastCached = System.currentTimeMillis();
			debug("BasicAuthAuthorizationInterceptor.loadUsers(): users not loaded, loading");
			
			if(null == users){
				users = new HashMap<String, String>();
			}
			
			//RESTConsignmentStatusServiceImpl RESTConsignmentStatusServiceImpl = new RESTConsignmentStatusServiceImpl();
			Map<String,String>  map = RESTEmployeeServiceImpl.getTotalEMPDetils();
			
                    if(null != map){
					for (Map.Entry<String, String> entry : map.entrySet()) {
						String key = entry.getKey();
						String value = entry.getValue();
						users.put(key, value);
					}
                    }
		
		}
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		debug("BasicAuthAuthorizationInterceptor.handleMessage() called");

		
		loadUsers();

		
		AuthorizationPolicy policy = message.get(AuthorizationPolicy.class);

		
		if (policy == null) {
			if (log.isDebugEnabled()) {
				log.debug("User attempted to log in with no credentials");
				debug("User attempted to log in with no credentials");
			}
			sendErrorResponse(message, HttpURLConnection.HTTP_UNAUTHORIZED);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("Logging in use: " + policy.getUserName());
		}

		
		String realPassword = users.get(policy.getUserName());
		if (DEBUG) {
			debug("md5 hash of users.get(user) = " + realPassword);
			debug("md5 hash of policy's password = "
					+ md5hash(policy.getPassword()));
		}
		
		/*if (realPassword == null
				|| !realPassword.equals(policy.getPassword())) {
			log.warn("Invalid username or password for user: "
					+ policy.getUserName());
			debug("Invalid username or password for user: "
					+ policy.getUserName());
			//sendErrorResponse(message, HttpURLConnection.HTTP_FORBIDDEN);
			//sendErrorResponse(message, HttpURLConnection.HTTP_UNAUTHORIZED);
			sendErrorResponse(message, HttpURLConnection.HTTP_UNAUTHORIZED);
			return;
		}*/
		debug("Message should be clear to finish being handled, auth succeeded");
		if (messageContext != null) {
			debug("MessageContext object set");
			messageContext.put("principal", policy.getUserName());
		} else {
			messageContext = new MessageContextImpl(message);
			messageContext.put("principal", policy.getUserName());
		}

		
		HttpServletRequest request = (HttpServletRequest) message.get(AbstractHTTPDestination.HTTP_REQUEST);
		if(null != request){
			request.setAttribute("userName",policy.getUserName());
			request.setAttribute("password",policy.getPassword());
			HttpSession session = request.getSession();
			session.removeAttribute("userName");
			session.removeAttribute("password");
			session.setAttribute("userName", policy.getUserName());
			session.setAttribute("password", policy.getPassword());
			
    		}
		
		
		message.put("X-Principal-Username", policy.getUserName());

		MultivaluedMap<String, Object> headers = new MetadataMap<String, Object>();
		headers.putSingle("X-Principal-Username", policy.getUserName());
		message.put(Message.PROTOCOL_HEADERS, headers);

		message.getInterceptorChain().resume();
	}

	@SuppressWarnings("unchecked")
	private void sendErrorResponse(Message message, int responseCode) {
		Message outMessage = getOutMessage(message);
		outMessage.put(Message.RESPONSE_CODE, responseCode);

		// Set the response headers
		Map<String, List<String>> responseHeaders = (Map<String, List<String>>) message
				.get(Message.PROTOCOL_HEADERS);
		if (responseHeaders != null) {
			responseHeaders.put("WWW-Authenticate",
					Arrays.asList(new String[] { "Basic realm=" + REALM }));
			responseHeaders.put("Content-length",
					Arrays.asList(new String[] { "0" }));
		}
		message.getInterceptorChain().abort();
		
		try {
			getConduit(message).prepare(outMessage);
			close(outMessage);
		} catch (IOException e) {
			log.warn(e.getMessage(), e);
		}
	}

	private Message getOutMessage(Message inMessage) {
		Exchange exchange = inMessage.getExchange();
		Message outMessage = exchange.getOutMessage();
		if (outMessage == null) {
			Endpoint endpoint = exchange.get(Endpoint.class);
			outMessage = endpoint.getBinding().createMessage();
			exchange.setOutMessage(outMessage);
		}
		outMessage.putAll(inMessage);
		return outMessage;
	}

	private Conduit getConduit(Message inMessage) throws IOException {
		Exchange exchange = inMessage.getExchange();
		EndpointReferenceType target = exchange
				.get(EndpointReferenceType.class);
		Conduit conduit = exchange.getDestination().getBackChannel(inMessage,
				null, target);
		exchange.setConduit(conduit);
		return conduit;
	}

	private void close(Message outMessage) throws IOException {
		OutputStream os = outMessage.getContent(OutputStream.class);
		os.flush();
		os.close();
	}

	/**
	 * Get MD5 hash of a string.
	 * 
	 * @param original
	 * @return
	 */
	protected String md5hash(String original) {
		log.info("md5 hash for " + original);
		MessageDigest digest = null;
		try {
			digest = java.security.MessageDigest.getInstance("MD5");
			digest.update(original.getBytes());
			byte[] hash = digest.digest();
			String hashed = asHex(hash);
			log.info("md5 hashed to " + hashed);
			debug("md5 hashed to " + hashed);
			return hashed;
		} catch (NoSuchAlgorithmException e) {
			log.error("Could not find MD5 algorithm", e);
			debug("Could not find MD5 algorithm: " + e.toString());
		}
		return null;
	}

	
	protected String asHex(byte hash[]) {
		char buf[] = new char[hash.length * 2];
		for (int i = 0, x = 0; i < hash.length; i++) {
			buf[x++] = HEX_CHARS[(hash[i] >>> 4) & 0xf];
			buf[x++] = HEX_CHARS[hash[i] & 0xf];
		}
		return new String(buf);
	}

	protected void debug(String st) {
		if (DEBUG) {
			System.out.println(this.getClass().getName() + "| " + st);
		}
	}

}