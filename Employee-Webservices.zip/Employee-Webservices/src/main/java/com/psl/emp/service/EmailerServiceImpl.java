package com.psl.emp.service;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.psl.emp.constant.EmailException;
import com.psl.emp.constant.PSLException;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

/**
 * @author mahender_kakkerla
 *
 */
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = PSLException.class)
public class EmailerServiceImpl implements EmailerService {

	private static final Logger logger = Logger.getLogger(EmailerServiceImpl.class);

	private JavaMailSender mailSender;

	private String userName;
	private String passWord;
	private String port;
	private boolean smtpAuth;
	private boolean smtpStarttls;
	private String smtpHost;
	private String transportProtocol;
	Session mailSession = null;

	private SimpleMailMessage preConfiguredMessage;

	public SimpleMailMessage getPreConfiguredMessage() {
		return preConfiguredMessage;
	}

	public void setPreConfiguredMessage(SimpleMailMessage preConfiguredMessage) {
		this.preConfiguredMessage = preConfiguredMessage;
	}

	public JavaMailSender getMailSender() {
		return mailSender;
	}

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	
	/********************** TO SEND A plain mail WITHOUT ATTACHMENT Using Spring JavaMailSender ************************************/
	public void sendMail(String to, String subject, String body) {

		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setTo(to);
			message.setSubject(subject);
			message.setText(body);
			mailSender.send(message);

		/*	MimeMessagePreparator preparator = new MimeMessagePreparator() {

				public void prepare(MimeMessage mimeMessage) throws OmniNGException {
					MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
					try {
						message.setTo("mahender_kakkerla@persistent.co.in");
						message.setFrom("mahender.kakkerla@gmail.com");
						message.setSubject("test subject");

						String body = "plain body";

						message.setText(body, true);
					} catch (MessagingException e) {
						e.printStackTrace();
					}
				}
			};

			mailSender.send(preparator);*/

		} catch (MailException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	 public void sendHtmlEmail(String host, String port,
	            final String userName, final String password, String toAddress,
	            String subject, String message) throws AddressException,
	            MessagingException {
	 
	        // sets SMTP server properties
	        Properties properties = new Properties();
	        properties.put("mail.smtp.host", host);
	        properties.put("mail.smtp.port", port);
	        properties.put("mail.smtp.auth", "true");
	        properties.put("mail.smtp.starttls.enable", "true");
	 
	        // creates a new session with an authenticator
	        Authenticator auth = new Authenticator() {
	            public PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(userName, password);
	            }
	        };
	 
	        Session session = Session.getInstance(properties, auth);
	 
	        // creates a new e-mail message
	        Message msg = new MimeMessage(session);
	 
	        msg.setFrom(new InternetAddress(userName));
	        InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
	        msg.setRecipients(Message.RecipientType.TO, toAddresses);
	        msg.setSubject(subject);
	        msg.setSentDate(new Date());
	        // set plain text message
	        msg.setContent(message, "text/html");
	 
	        // sends the e-mail
	        Transport.send(msg);
	 
	    }

}
