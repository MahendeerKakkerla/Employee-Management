package com.psl.emp.service;

import java.util.List;

import com.psl.emp.constant.PSLException;
import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.form.EmployeeForm;

/**
 * @author mahender_kakkerla
 *
 */
public interface ValidateLogingUserService {

	/**
	 * Gets the login Details.
	 * @param loginId and password
	 * @return the EmployeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm getUserDetails(EmployeeForm employeeForm) throws PSLException;
	
	/**
	 * save Employee Details 
	 * @param employeeForm
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm saveEmployee(EmployeeForm employeeForm) throws PSLException;
	
	/**
	 * get Employee Details
	 * @param employeeCode 
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm getEmployee(EmployeeForm employeeForm) throws PSLException;
	
	/**
	 * get Total Employee Details
	 * @param employeeCode 
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public List<EmployeeForm> getEmployeeDetails() throws PSLException;
	
	
	/**
	 * save Employee Details 
	 * @param employeeForm
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm getEmployeeForAdmin(EmployeeForm employeeForm) throws PSLException;
	/**
	 * check Employee Details
	 * @param employeeCode 
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public Boolean checkEmployee(EmployeeForm employeeForm) throws PSLException;
	
	/**
	 * get Employee Details
	 *  
	 * @return EmployeeDO List
	 * @throws PSLException exception
	 * 
	 */
	public List<EmployeeDO> getEmployeeWSList() throws PSLException ;
	
	
	/**
	 * Gets the login Details.
	 * @param loginId and password
	 * @return the EmployeeDO
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeDO getUserWSDetails(EmployeeDO employeeDo) throws PSLException;
	/**
	 * Gets the login Details. From WebService.
	 * @param employeeCode 
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm getLoginEmployeeDetails(EmployeeForm employeeForm) throws PSLException;
	/**
	 * get Employee Details From WebService.
	 *  
	 * @return EmployeeDO List
	 * @throws PSLException exception
	 * 
	 */
	public List<EmployeeForm> getEmployeeWSDetails() throws PSLException;
	

	/**
	 * save Employee Details From WebService.
	 * @param employeeForm
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm getWSEmployeeForAdmin(EmployeeForm employeeForm) throws PSLException;
	
	
	/**
	 * check Employee Details From WebService.
	 * @param employeeCode 
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public Boolean checkWSEmployee(EmployeeForm employeeForm) throws PSLException;
	

	/**
	 * save Employee Details From WebService.
	 * @param employeeForm
	 * @return employeeForm
	 * @throws PSLException exception
	 * 
	 */
	public EmployeeForm saveWSEmployee(EmployeeForm employeeForm) throws PSLException;
	
	
	/**
	 * delete Employee Details From WebService.
	 * @param employeeForm
	 * @return 
	 * @throws PSLException exception
	 * 
	 */
	public void deleteEmployee(EmployeeForm employeeForm) throws PSLException;
	
}
