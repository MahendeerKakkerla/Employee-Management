
package com.psl.emp.utils;

import java.util.Collection;



/**
 * The Class StringUtil.
 * 
 * @author Mahender Kakkerla
 */

public abstract class StringUtil {

	
	
	@SuppressWarnings("rawtypes")
	public static Boolean isEmptyColletion(Collection arrayList) {
		Boolean isListEmpty = true;
		if (arrayList != null && !arrayList.isEmpty()) {
			isListEmpty = false;

		}
		return isListEmpty;
	}


}
