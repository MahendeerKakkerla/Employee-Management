package com.psl.emp.webService;

import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.web.bind.annotation.RequestBody;

import com.psl.emp.ws.vo.EmployeeWSInput;



@Produces("application/json")
@Consumes("application/json")
public interface RESTEmployeeService {
	

	@POST
	@Path("/getEmployeeWSList")  // Not Access By Employee
	public EmployeeWSInput getEmployeeWSList(EmployeeWSInput employeeWSInput);
	
	
	@POST
	@Path("/getLogoutEmployeeDetails")
	public EmployeeWSInput getLoginEmployeeDetails(@RequestBody EmployeeWSInput employeeWSInput);
	
	@POST
	@Path("/updateWSEmployee")
	public String updateWSEmployee(@RequestBody EmployeeWSInput employeeWSInput);
	
	@POST
	@Path("/deleteEmployee")  // Not Access By Employee
	public String deleteEmployee(@RequestBody EmployeeWSInput employeeWSInput);
	
	
	@POST
	@Path("/saveWSEmployee")  // Not Access By Employee
	public String saveWSEmployee(@RequestBody EmployeeWSInput employeeWSInput);
	
	@POST
	@Path("/loginUser")
	public EmployeeWSInput loginUser();
	
	public Map<String, String> getTotalEMPDetils();
	
	@POST
	@Path("/deleteChildRecord")
	public String deleteChildRecord(@RequestBody EmployeeWSInput employeeWSInput);
	
	public String invalidLoginUser();

}
