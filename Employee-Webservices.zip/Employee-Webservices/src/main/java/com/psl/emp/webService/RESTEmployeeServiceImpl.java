package com.psl.emp.webService;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;

import org.apache.cxf.jaxrs.ext.MessageContext;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.psl.emp.dao.ValidateLogingUserDAO;
import com.psl.emp.domain.EmployeeDO;
import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;
import com.psl.emp.service.ValidateLogingUserService;
import com.psl.emp.utils.SpringUtil;
import com.psl.emp.ws.mapper.UserObjectMapper;
import com.psl.emp.ws.vo.EmployeeWSDO;
import com.psl.emp.ws.vo.EmployeeWSInput;


@Component
@Service("RESTEmployeeService")
public class RESTEmployeeServiceImpl implements RESTEmployeeService{
	static Logger logger = Logger.getLogger(RESTEmployeeServiceImpl.class);
	
	@Context 
	private MessageContext context;
	
	private	ValidateLogingUserService validateLogingUserService = (ValidateLogingUserService) SpringUtil.getSpringUtil()
			.getService("validateLogingUserService");
private	ValidateLogingUserDAO validateLogingUserDAO = (ValidateLogingUserDAO) SpringUtil.getSpringUtil()
.getService("validateLogingUserDAO");


	public EmployeeWSInput getEmployeeWSList(EmployeeWSInput employeeWSInput) {
		logger.info("RESTEmployeeServiceImpl :: getEmployeeList :: start");

		// check input details
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
		

		// check Auth_Token validation
		EmployeeDO empDO = getUser();
		if(null == empDO){
			employeeWSoutput.setErrorMsg("Invalid Credentials");
			return employeeWSoutput;
		}
		
		if (null == employeeWSInput.getAuthToken()
				|| !employeeWSInput.getAuthToken().equalsIgnoreCase(empDO.getAuthToken())) {
			employeeWSoutput.setErrorMsg("Invalid Authtoken..");
			return employeeWSoutput;
		}
		if (empDO.getEmpType().equalsIgnoreCase("Employee")) {
			employeeWSoutput.setErrorMsg("Invalid User To Access Employee List..");
			return employeeWSoutput;
		}
         // send Employee List
		List<EmployeeDO> employeeDos = validateLogingUserService.getEmployeeWSList();
		if (null != employeeDos) {
			for (EmployeeDO empdo : employeeDos) {
				EmployeeWSDO employeeWSDO1 = UserObjectMapper.copyToEmployeeWSDO(empdo);
				employeeWSList.add(employeeWSDO1);
			}
			employeeWSoutput.setEmployeeList(employeeWSList);

		} else {
			employeeWSoutput.setErrorMsg("No Employee List Found..");
			return employeeWSoutput;
		}
		logger.info("RESTEmployeeServiceImpl :: getEmployeeList :: End");
		return employeeWSoutput;

	}
	
	public EmployeeWSInput getLoginEmployeeDetails(EmployeeWSInput employeeWSInput) {
		logger.info("RESTEmployeeServiceImpl :: getLoginEmployeeDetails :: start");

		// check input details
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList1 = employeeWSInput.getEmployeeList();
		if (null == employeeWSList1 || employeeWSList1.size() == 0) {
			employeeWSoutput.setErrorMsg("No Employee Input Details Found..");
			return employeeWSoutput;
		}

		// check Auth_Token validation
		EmployeeDO empDO = getUser();
		if(null == empDO){
			employeeWSoutput.setErrorMsg("Invalid Credentials");
			return employeeWSoutput;
		}
		EmployeeWSDO employeeWSDO2 = employeeWSList1.get(0);
		if (null == employeeWSInput.getAuthToken()
				|| !employeeWSInput.getAuthToken().equalsIgnoreCase(empDO.getAuthToken())) {
			employeeWSoutput.setErrorMsg("Invalid Authtoken..");
			return employeeWSoutput;
		}

		EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO2);
		 if(employeeDO.getEmployeeCode() == null ){
			 employeeWSoutput.setErrorMsg("EmployeeCode Is Mandatory to Get Data..");
				return employeeWSoutput;
		 }
		 if (empDO.getEmpType().equalsIgnoreCase("Employee") && !empDO.getEmployeeCode().equalsIgnoreCase(employeeDO.getEmployeeCode())) {
				employeeWSoutput.setErrorMsg("Invalid Employee Code..");
				return employeeWSoutput;
			}
		
		EmployeeDO employeeExitDO = validateLogingUserDAO.getEmployeeForAdmin(employeeDO);
		if (null != employeeExitDO) {

			EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
			employeeWSList.add(employeeExistWSDO);
		} else {
			return null;
		}

		employeeWSoutput.setEmployeeList(employeeWSList);

		logger.info("RESTEmployeeServiceImpl :: getLoginEmployeeDetails :: End");

		return employeeWSoutput;

	}
	
	
	public String updateWSEmployee(@RequestBody EmployeeWSInput employeeWSInput){
		
		         // check input details
				EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
				List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
				List<EmployeeWSDO> employeeWSList1 = employeeWSInput.getEmployeeList();
				if (null == employeeWSList1 || employeeWSList1.size() == 0) {
					employeeWSoutput.setErrorMsg("No Employee Input Details Found..");
					return "No Employee Input Details Found..";
				}

				// check Auth_Token validation
				EmployeeDO empDO = getUser();
				if(null == empDO){
					employeeWSoutput.setErrorMsg("Invalid Credentials");
					return "Invalid Credentials";
				}
				EmployeeWSDO employeeWSDO2 = employeeWSList1.get(0);
				if (null == employeeWSInput.getAuthToken()
						|| !employeeWSInput.getAuthToken().equalsIgnoreCase(empDO.getAuthToken())) {
					employeeWSoutput.setErrorMsg("Invalid Authtoken..");
					return "Invalid Authtoken..";
				}

				
				EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO2);
                if(empDO.getEmpType().equalsIgnoreCase("Admin")){
                	empDO = validateLogingUserDAO.getEmployeeForAdmin(employeeDO);
				}else{
					String error = ValidationCheckForEmployeeLogin(empDO, employeeDO);
					if(null != error){
						return error;
					}
					employeeDO.setCreationDate(new Date());
					employeeDO.setLogoutTime(new Date());
				}
			
			employeeDO = checkChildsToSave(empDO , employeeDO);
			
			// Mandatory check 
			if(validateEmployee(employeeDO)){
				EmployeeDO employeeExitDO = validateLogingUserDAO.saveOrUpdateEmployee(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSList.add(employeeExistWSDO);
			} else {
				return "No Details Found..";
			}
			}else{
				return "Mandatory Information Missed From Employee";
			}
		employeeWSoutput.setEmployeeList(employeeWSList);
        return "Saved Successfully.....";
	}
	
	public String deleteChildRecord(@RequestBody EmployeeWSInput employeeWSInput){
		
        // check input details
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList1 = employeeWSInput.getEmployeeList();
		if (null == employeeWSList1 || employeeWSList1.size() == 0) {
			employeeWSoutput.setErrorMsg("No Employee Input Details Found..");
			return "No Employee Input Details Found..";
		}

		// check Auth_Token validation
		EmployeeDO empDO = getUser();
		if(null == empDO){
			employeeWSoutput.setErrorMsg("Invalid Credentials");
			return "Invalid Credentials";
		}
		EmployeeWSDO employeeWSDO2 = employeeWSList1.get(0);
		if (null == employeeWSInput.getAuthToken()
				|| !employeeWSInput.getAuthToken().equalsIgnoreCase(empDO.getAuthToken())) {
			employeeWSoutput.setErrorMsg("Invalid Authtoken..");
			return "Invalid Authtoken..";
		}

		
		EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO2);
		if(empDO.getEmpType().equalsIgnoreCase("Admin")){
        	empDO = validateLogingUserDAO.getEmployeeForAdmin(employeeDO);
		}else{
			return "Invalid User To Delete Employee Details.";
		}
		employeeDO = checkChildsToDelete(empDO, employeeDO);
		// Mandatory check
		if (validateEmployee(employeeDO)) {
			EmployeeDO employeeExitDO = validateLogingUserDAO.saveOrUpdateEmployee(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSList.add(employeeExistWSDO);
			} else {
				return "No Details Found..";
			}
		} else {
			return "Mandatory Information Missed From Employee";
		}
employeeWSoutput.setEmployeeList(employeeWSList);
return "Child Deleted Successfully.....";
}
	
	public String deleteEmployee(@RequestBody EmployeeWSInput employeeWSInput) {

		// check input details
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList1 = employeeWSInput.getEmployeeList();
		if (null == employeeWSList1 || employeeWSList1.size() == 0) {
			employeeWSoutput.setErrorMsg("No Employee Input Details Found..");
			return "No Employee Input Details Found..";
		}

		// check Auth_Token validation
		EmployeeDO empDO = getUser();
		if(null == empDO){
			employeeWSoutput.setErrorMsg("Invalid Credentials");
			return "Invalid Credentials";
		}
		EmployeeWSDO employeeWSDO2 = employeeWSList1.get(0);
		if (null == employeeWSInput.getAuthToken()
				|| !employeeWSInput.getAuthToken().equalsIgnoreCase(empDO.getAuthToken())) {
			employeeWSoutput.setErrorMsg("Invalid Authtoken..");
			return "Invalid Authtoken..";
		}
		if (empDO.getEmpType().equalsIgnoreCase("Employee")) {
			employeeWSoutput.setErrorMsg("Invalid User To Access Employee List..");
			return "Invalid User To Dlete Employee ";
		}

		EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO2);
		
		if(null == employeeDO.getEmployeeId()){
			return "Employee Id Missed";
		}
		validateLogingUserDAO.deleteEmployee(employeeDO);

		employeeWSoutput.setEmployeeList(employeeWSList);

		return "Deleted Successfully..";
	}
	
	
	private EmployeeDO checkChildsToSave(EmployeeDO existingEmployeeDO, EmployeeDO newEmployeeDO) {
		Set<EmployeeLogoutTimeDetailsDO> existingDetailsDOs = existingEmployeeDO.getDetailsDO();
		Set<EmployeeLogoutTimeDetailsDO> currentDetailsDOs = newEmployeeDO.getDetailsDO();
		if (null != existingDetailsDOs && null != currentDetailsDOs) {

			List<Integer> detailIds = new ArrayList<Integer>();

			for (EmployeeLogoutTimeDetailsDO newdetailDO : currentDetailsDOs) {
				if (null != newdetailDO.getDetailId()) {
					detailIds.add(newdetailDO.getDetailId());
				}

			}
			for (EmployeeLogoutTimeDetailsDO existdetailDO : existingDetailsDOs) {
				if (detailIds.contains(existdetailDO.getDetailId())) {

				} else {
					currentDetailsDOs.add(existdetailDO);
				}
			}
			newEmployeeDO.setDetailsDO(currentDetailsDOs);
		}

		if (null == currentDetailsDOs && null != existingDetailsDOs) {
			newEmployeeDO.setDetailsDO(existingDetailsDOs);
		}

		return newEmployeeDO;

	}
	
	private EmployeeDO checkChildsToDelete(EmployeeDO existingEmployeeDO, EmployeeDO newEmployeeDO) {
		Set<EmployeeLogoutTimeDetailsDO> existingDetailsDOs = existingEmployeeDO.getDetailsDO();
		Set<EmployeeLogoutTimeDetailsDO> currentDetailsDOs = newEmployeeDO.getDetailsDO();
		Set<EmployeeLogoutTimeDetailsDO> deleteDos = new HashSet<EmployeeLogoutTimeDetailsDO>();
			
			
		if (null != existingDetailsDOs && null != currentDetailsDOs) {

			List<Integer> detailIds = new ArrayList<Integer>();

			for (EmployeeLogoutTimeDetailsDO newdetailDO : currentDetailsDOs) {
				if (null != newdetailDO.getDetailId()) {
					detailIds.add(newdetailDO.getDetailId());
				}

			}
			for (EmployeeLogoutTimeDetailsDO existdetailDO : existingDetailsDOs) {
				if (detailIds.contains(existdetailDO.getDetailId())) {

				} else {
					deleteDos.add(existdetailDO);
				}
			}
			newEmployeeDO.setDetailsDO(deleteDos);
		}

		if (null == currentDetailsDOs && null != existingDetailsDOs) {
			newEmployeeDO.setDetailsDO(existingDetailsDOs);
		}

		return newEmployeeDO;

	}
	
	
	
	public String saveWSEmployee(@RequestBody EmployeeWSInput employeeWSInput) {

		// check input details
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		List<EmployeeWSDO> employeeWSList = new ArrayList<EmployeeWSDO>();
		List<EmployeeWSDO> employeeWSList1 = employeeWSInput.getEmployeeList();
		if (null == employeeWSList1 || employeeWSList1.size() == 0) {
			employeeWSoutput.setErrorMsg("No Employee Input Details Found..");
			return "No Employee Input Details Found..";
		}

		// check Auth_Token validation
		EmployeeDO empDO = getUser();
		if(null == empDO){
			employeeWSoutput.setErrorMsg("Invalid Credentials");
			return "Invalid Credentials";
		}
		EmployeeWSDO employeeWSDO2 = employeeWSList1.get(0);
		if (null == employeeWSInput.getAuthToken()
				|| !employeeWSInput.getAuthToken().equalsIgnoreCase(empDO.getAuthToken())) {
			employeeWSoutput.setErrorMsg("Invalid Authtoken..");
			return "Invalid Authtoken..";
		}
		if (empDO.getEmpType().equalsIgnoreCase("Employee")) {
			employeeWSoutput.setErrorMsg("Invalid User To Access Employee List..");
			return "Invalid User To Save Employee..";
		}
		EmployeeDO employeeDO = UserObjectMapper.copyToEmployeeDO(employeeWSDO2);

		// Mandatory check
		if (validateEmployee(employeeDO)) {
			employeeDO.setAuthToken(null);
			EmployeeDO employeeExitDO = validateLogingUserDAO.saveOrUpdateEmployee(employeeDO);
			if (null != employeeExitDO) {

				EmployeeWSDO employeeExistWSDO = UserObjectMapper.copyToEmployeeWSDO(employeeExitDO);
				employeeWSList.add(employeeExistWSDO);
			} else {
				return "No Details Found..";
			}
		} else {
			return "Mandatory Information Missed From Employee";
		}

		employeeWSoutput.setEmployeeList(employeeWSList);

		return "Saved Successfully.....";
	}
	
	public EmployeeWSInput loginUser(){
		EmployeeWSInput employeeWSoutput = new EmployeeWSInput();
		
		// getting Random String
		String randomString = generateString();
		
		// save random String in Database
		EmployeeDO employeeDo = getUser();
		if(null == employeeDo){
			employeeWSoutput.setErrorMsg("Invalid Credentials");
			return employeeWSoutput;
		}
		employeeDo.setAuthToken(randomString);
		employeeDo = validateLogingUserDAO.saveOrUpdateEmployee(employeeDo);
		
		// send Random String back as Response
		List<EmployeeWSDO> employeeWSOutputList = new ArrayList<EmployeeWSDO>();
		EmployeeWSDO wsDO = new EmployeeWSDO();
		
		employeeWSOutputList.add(wsDO);
		employeeWSoutput.setAuthToken(randomString);
		employeeWSoutput.setEmployeeList(employeeWSOutputList);
		
	return employeeWSoutput;
	}

	public Map<String, String> getTotalEMPDetils() {
		Map<String, String> userMap = new HashMap<String, String>();
		logger.info("RESTEmployeeServiceImpl :: getTotalEMPDetils :: Start");
		List<EmployeeDO> employeeDos = validateLogingUserDAO.getTotalEmployeeDetails();
		for (EmployeeDO emp : employeeDos) {
			userMap.put(emp.getEmailId(), emp.getPassword());
		}
		logger.info("RESTEmployeeServiceImpl :: getTotalEMPDetils :: End");
		return userMap;
	}
	 private static String generateString() {
	        String uuid = UUID.randomUUID().toString();
	        return  uuid;
	   }
	 
	 private EmployeeDO getUser(){
		 HttpServletRequest req = context.getHttpServletRequest();
			HttpSession session =req.getSession();
			String emailId = (String)session.getAttribute("userName");
			String password = (String)session.getAttribute("password");
			EmployeeDO empDO = new EmployeeDO();
			empDO.setEmailId(emailId);
			empDO.setPassword(password);
			EmployeeDO employeeDo = validateLogingUserDAO.getEmployeeLogin(empDO);
			return employeeDo;
	 }
	 
	 
	 private boolean validateEmployee(EmployeeDO empDo){
		 boolean isValide = true;
		 if(empDo.getEmailId() == null){
			 isValide = false;
		 }
		 if(empDo.getEmployeeCode() == null){
			 isValide = false;
		 }
		 if(empDo.getEmpStatus() == null){
			 isValide = false;
		 }
		 if(empDo.getEmpType() == null){
			 isValide = false;
		 }
		 if(empDo.getPassword() == null){
			 isValide = false;
		 }
		
		 
		 
	 return isValide;
	 }

	 private String ValidationCheckForEmployeeLogin(EmployeeDO existingEmpDo , EmployeeDO currentEmpDo){
		 String error = null;
		 
		
			if(existingEmpDo.getEmployeeId() != currentEmpDo.getEmployeeId()){
				error = "Employee Id Missed..";
				return error;
			 }
			if(existingEmpDo.getFirstName() != null && !existingEmpDo.getFirstName().equalsIgnoreCase(currentEmpDo.getFirstName())){
				error = "Invalid First Name..";
				return error;
			}
			if(existingEmpDo.getLastName() != null && !existingEmpDo.getLastName().equalsIgnoreCase(currentEmpDo.getLastName())){
				error = "Invalid Last Name..";
				return error;
			}
			if(existingEmpDo.getEmployeeCode() != null && !existingEmpDo.getEmployeeCode().equalsIgnoreCase(currentEmpDo.getEmployeeCode())){
				error = "Invalid EmployeeCode..";
				return error;
			}
			if(existingEmpDo.getPhone() != null && !existingEmpDo.getPhone().equalsIgnoreCase(currentEmpDo.getPhone())){
				error = "Invalid Moblie Number..";
				return error;
			}
			if(existingEmpDo.getDesignation() != null && !existingEmpDo.getDesignation().equalsIgnoreCase(currentEmpDo.getDesignation())){
				error = "Invalid Designation..";
				return error;
			}
			if(existingEmpDo.getDepartment() != null && !existingEmpDo.getDepartment().equalsIgnoreCase(currentEmpDo.getDepartment())){
				error = "Invalid Department..";
			}
			if(existingEmpDo.getCity() != null && !existingEmpDo.getCity().equalsIgnoreCase(currentEmpDo.getCity())){
				error = "Invalid City..";
				return error;
			}
			if(existingEmpDo.getOffice() != null && !existingEmpDo.getOffice().equalsIgnoreCase(currentEmpDo.getOffice())){
				error = "Invalid Office..";
				return error;
			}
			if(existingEmpDo.getEmailId() != null && !existingEmpDo.getEmailId().equalsIgnoreCase(currentEmpDo.getEmailId())){
				error = "Invalid Email..";
				return error;
			}
			if(existingEmpDo.getManagerEmailId() != null && !existingEmpDo.getManagerEmailId().equalsIgnoreCase(currentEmpDo.getManagerEmailId())){
				error = "Invalid ManagerEmail..";
				return error;
			}
			if(existingEmpDo.getEmpStatus() != null && !existingEmpDo.getEmpStatus().equalsIgnoreCase(currentEmpDo.getEmpStatus())){
				error = "Invalid EmpStatus..";
				return error;
			}
			if(existingEmpDo.getPassword() != null && !existingEmpDo.getPassword().equalsIgnoreCase(currentEmpDo.getPassword())){
				error = "Invalid Password..";
				return error;
			}
			if(existingEmpDo.getEmpType() != null && !existingEmpDo.getEmpType().equalsIgnoreCase(currentEmpDo.getEmpType())){
				error = "Invalid EmpType..";
				return error;
			}
			if(existingEmpDo.getAddress1() != null && !existingEmpDo.getAddress1().equalsIgnoreCase(currentEmpDo.getAddress1())){
				error = "Invalid Address1..";
				return error;
			}
			if(existingEmpDo.getAddress2() != null && !existingEmpDo.getAddress2().equalsIgnoreCase(currentEmpDo.getAddress2())){
				error = "Invalid Address2..";
				return error;
			}
			if(existingEmpDo.getState() != null && !existingEmpDo.getState().equalsIgnoreCase(currentEmpDo.getState())){
				error = "Invalid State..";
				return error;
			}
			if(existingEmpDo.getPincode() != null && !existingEmpDo.getPincode().equalsIgnoreCase(currentEmpDo.getPincode())){
				error = "Invalid Pincode..";
				return error;
			}
			if(existingEmpDo.getAuthToken() != null && !existingEmpDo.getAuthToken().equalsIgnoreCase(currentEmpDo.getAuthToken())){
				error = "Invalid AuthToken..";
				return error;
			}
			if(existingEmpDo.getCreatedby() != null && !existingEmpDo.getCreatedby().equalsIgnoreCase(currentEmpDo.getCreatedby())){
				error = "Invalid Createdby..";
				return error;
			}
			
			Set<EmployeeLogoutTimeDetailsDO> setDetailDos = currentEmpDo.getDetailsDO();
			if(null == setDetailDos || setDetailDos.size() == 0){
				error = "No Child Details Found To Update";
				return error;
			}
			EmployeeLogoutTimeDetailsDO detailsDO = null;
					for(EmployeeLogoutTimeDetailsDO firstDo: setDetailDos) {
						detailsDO = firstDo;
					    break;
					}
					if(null == detailsDO ){
						error = "No Child Details Found To Update";
						return error;
					}
					if(detailsDO.getDetailId() != 0  && detailsDO.getDetailId() != null){
						error = " Child DetailId Should Be Zero";
						return error;
					}
					
			
		 
		 return error;
	 }
	 public String invalidLoginUser(){
		 return "Invalid Login User..";
	 }
	}
