package com.psl.emp.ws.vo;

import com.psl.emp.domain.EmployeeDO;

/**
 * @author mahender_kakkerla
 *
 */
public class EmployeeLogoutTimeDetailsWSDO {

	
 private static final long serialVersionUID = -473562596852452021L;
	 
	 private Integer detailId;
	    private String outDate;
	    private String outTime;
	    private String dayName;
	   
	    private Integer header;

		public Integer getDetailId() {
			return detailId;
		}

		public void setDetailId(Integer detailId) {
			this.detailId = detailId;
		}

		public String getOutDate() {
			return outDate;
		}

		public void setOutDate(String outDate) {
			this.outDate = outDate;
		}

		public String getOutTime() {
			return outTime;
		}

		public void setOutTime(String outTime) {
			this.outTime = outTime;
		}

		public String getDayName() {
			return dayName;
		}

		public void setDayName(String dayName) {
			this.dayName = dayName;
		}

		public Integer getHeader() {
			return header;
		}

		public void setHeader(Integer header) {
			this.header = header;
		}
	    
	    
	    
}
