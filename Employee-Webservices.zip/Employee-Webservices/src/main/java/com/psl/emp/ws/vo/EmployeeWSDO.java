package com.psl.emp.ws.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.psl.emp.domain.EmployeeLogoutTimeDetailsDO;

/**
 * @author mahender_kakkerla
 *
 */
public class EmployeeWSDO {

	 private static final long serialVersionUID = -473562596852452021L;

	    private Integer employeeId =0;
	    private String firstName = "";
	    private String lastName = "";
	    private String employeeCode = "";
	    private String phone = "";
	    private String designation = "";
	   
	    private String department = "";
	    private String city = "";
	    private String office = "";
	    private String emailId = "";
	    private String managerEmailId = "";
	    private String logoutTime = "";
	    private String createdby = "";
	    private String creationDate = "";
	    private String empStatus = "";
	    
	    private String password ="";
		 
		private String empType ="";
	    private String address1 = "";
	    private String address2 = "";
	    private String state = "";
	    private String pincode = "";
	    private String authToken = "";
	    private List<EmployeeLogoutTimeDetailsWSDO> detailsDO = new ArrayList<EmployeeLogoutTimeDetailsWSDO>();
	    
		public Integer getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(Integer employeeId) {
			this.employeeId = employeeId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getEmployeeCode() {
			return employeeCode;
		}
		public void setEmployeeCode(String employeeCode) {
			this.employeeCode = employeeCode;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getOffice() {
			return office;
		}
		public void setOffice(String office) {
			this.office = office;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getManagerEmailId() {
			return managerEmailId;
		}
		public void setManagerEmailId(String managerEmailId) {
			this.managerEmailId = managerEmailId;
		}
		public String getLogoutTime() {
			return logoutTime;
		}
		public void setLogoutTime(String logoutTime) {
			this.logoutTime = logoutTime;
		}
		public String getCreatedby() {
			return createdby;
		}
		public void setCreatedby(String createdby) {
			this.createdby = createdby;
		}
		public String getCreationDate() {
			return creationDate;
		}
		public void setCreationDate(String creationDate) {
			this.creationDate = creationDate;
		}
		public String getEmpStatus() {
			return empStatus;
		}
		public void setEmpStatus(String empStatus) {
			this.empStatus = empStatus;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getEmpType() {
			return empType;
		}
		public void setEmpType(String empType) {
			this.empType = empType;
		}
		public String getAddress1() {
			return address1;
		}
		public void setAddress1(String address1) {
			this.address1 = address1;
		}
		public String getAddress2() {
			return address2;
		}
		public void setAddress2(String address2) {
			this.address2 = address2;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getPincode() {
			return pincode;
		}
		public void setPincode(String pincode) {
			this.pincode = pincode;
		}
		public List<EmployeeLogoutTimeDetailsWSDO> getDetailsDO() {
			return detailsDO;
		}
		public void setDetailsDO(List<EmployeeLogoutTimeDetailsWSDO> detailsDO) {
			this.detailsDO = detailsDO;
		}
		public String getAuthToken() {
			return authToken;
		}
		public void setAuthToken(String authToken) {
			this.authToken = authToken;
		}
	
	    
	    
	    
	    
	    
	    
}
