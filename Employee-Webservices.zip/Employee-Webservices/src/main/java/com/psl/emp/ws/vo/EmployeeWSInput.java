package com.psl.emp.ws.vo;

import java.util.List;

import com.psl.emp.domain.EmployeeDO;
/**
 * @author Mahender Kakkerla
 *
 */
public class EmployeeWSInput {
	/*
	 * THis <code> holds employeeList input/output for web service
	 */
	private List<EmployeeWSDO> employeeList;
	
	private String errorMsg = "";
	private String authToken = "";

	public List<EmployeeWSDO> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<EmployeeWSDO> employeeList) {
		this.employeeList = employeeList;
	}

	

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	
	

}
